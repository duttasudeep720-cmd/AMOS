# AMOS — Desiretech Account Management Operating System

A hierarchical Amazon (India-first) account-management system: it ingests marketplace reports,
detects problems and opportunities across catalogue/ads/inventory/pricing/health/compliance/CX,
turns them into a prioritised, exception-driven task queue with human-approval guardrails, and
tracks whether the fix actually worked. See `ARCHITECTURE.md` for the full design brief and
`HANDOVER.md` for build status.

Python 3.10+, standard library only (sqlite3 + http.server). No install step, no dependencies.

## Quick start

```bash
# from this folder:
export AMOS_DB=data/amos.db          # optional — this is the default anyway

python -m amos seed                  # creates demo account #1 (Krishna Enterprises) + sample CSVs
python -m amos cycle --account 1     # detect -> issues -> tasks -> verify -> measure
python -m amos brief --account 1     # today's exception-driven brief, as Markdown
python -m amos serve                 # dashboard at http://localhost:8000
```

Open the dashboard, or keep using the CLI:

```bash
python -m amos tasks --account 1                        # the work queue, P1 first
python -m amos approve 15 --account 1                    # approve a pending_approval task
python -m amos execute 15 --account 1                     # run it (dry-run by default)
python -m amos reject 4 --account 1 --reason "..."        # reject a pending_decision task
python -m amos demo-fix --account 1                       # [demo only] simulate the market reacting
python -m amos cycle --account 1                          # re-run to verify + measure outcomes
python -m amos precheck samples/listings.csv --account 1  # compliance PASS/FAIL before upload
python -m amos coverage --account 1                        # what data AMOS has, how fresh, what's missing
python -m amos org                                        # org chart + skill registry, as JSON
python -m amos --help                                     # every command
```

Run the test suite (uses an in-memory DB, never touches `data/amos.db`):

```bash
pip install pytest --break-system-packages   # only dependency, and only for testing
python -m pytest tests/
```

## Using it with real client data

`amos ingest --account <id> --kind <kind> --file <path>` loads a CSV/XLSX export into the
matching table (`amos.ingest.KINDS` lists the supported kinds: listings, campaigns, search_terms,
inventory, orders, returns, health_metrics, daily_performance). Column names are matched
case-insensitively against Amazon's standard report headers; unmatched columns are ignored rather
than erroring, so partial exports still ingest.

To onboard a real account instead of the seeded demo one, add a row via `core.py`'s schema (see
`demo.py::seed` for the exact shape of an account config: targets, thresholds, hero-SKU share,
autonomy phase) — a small `amos accounts create` CLI command is the natural next addition once
you have a second real client to onboard (see HANDOVER's "Next up").

## Layout

```
amos/
  core.py        sqlite schema + connection + shared helpers
  skills/        detection functions (pure fn(ctx) -> list[Finding])
  org.py         organisational hierarchy built from skills/
  engines/       execution hierarchy: exception, priority, policy, tasks, execution,
                 verification, learning
  director.py    runs one full cycle for one account
  ingest.py      raw exports -> sqlite tables
  reporting.py   dashboard aggregates + daily/weekly briefs
  demo.py        seeds a realistic demo account; simulates fixes for the demo
  cli.py         python -m amos ...
  server.py      stdlib dashboard server
  web/index.html the dashboard itself
tests/test_amos.py   29 tests, run with pytest
```

## Safety model

Every action type has a base autonomy level (0 fully automatic, 1 agent-executes-in-rules,
2 agent-recommends/human-approves, 3 agent-detects/human-decides, 4 human-only), which
`engines/policy.py` can only ever raise per-case based on the actual numbers involved (e.g. a
large bid change needs more sign-off than a small one), never lower. Execution defaults to
`dry_run` mode everywhere — nothing touches a real marketplace until an account's config is
switched to a live SP-API/Ads API connector in `engines/execution.py`.
