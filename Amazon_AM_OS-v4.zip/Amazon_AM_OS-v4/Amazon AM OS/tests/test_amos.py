"""End-to-end + unit tests for AMOS. Run with:  python -m pytest tests/  (or: python tests/test_amos.py)

Uses an in-memory sqlite DB per test (core.connect(":memory:")) so tests never touch data/amos.db
and can run in parallel / on CI with no setup.
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from amos import core, demo, ingest, org, reporting  # noqa: E402
from amos.director import AccountDirector  # noqa: E402
from amos.engines import policy, priority, tasks as tasks_engine  # noqa: E402
from amos.skills import Ctx, metrics  # noqa: E402
from amos.skills.compliance import validate_listing  # noqa: E402


def seeded_conn():
    conn = core.connect(":memory:")
    tmp = tempfile.mkdtemp()
    aid = demo.seed(conn, tmp, phase=1)
    return conn, aid


class TestOrgAndSkills(unittest.TestCase):
    def test_every_skill_is_owned_exactly_once(self):
        from amos.skills import SKILLS
        owned = [s for d in org.ORG for s in d.skills]
        self.assertEqual(len(owned), len(set(owned)), "a skill is owned by two agents")
        self.assertEqual(set(SKILLS), set(owned), "unowned or unregistered skill")

    def test_describe_is_json_serialisable(self):
        import json
        json.dumps(org.describe(), default=str)  # must not raise


class TestPolicy(unittest.TestCase):
    def setUp(self):
        self.cfg = core.DEFAULT_CONFIG

    def test_small_bid_change_is_level1(self):
        level, _ = policy.decide("ADJUST_BID", {"change_pct": -10}, self.cfg)
        self.assertEqual(level, 1)

    def test_large_bid_change_is_level2(self):
        level, _ = policy.decide("ADJUST_BID", {"change_pct": -25}, self.cfg)
        self.assertEqual(level, 2)

    def test_price_below_floor_is_level3(self):
        level, _ = policy.decide("ADJUST_PRICE", {"new_price": 500, "floor": 600}, self.cfg)
        self.assertEqual(level, 3)

    def test_price_change_never_below_level2(self):
        level, _ = policy.decide("ADJUST_PRICE", {"new_price": 640, "floor": 600}, self.cfg)
        self.assertGreaterEqual(level, 2)

    def test_agent_never_executes_below_phase3(self):
        self.assertFalse(policy.agent_may_execute(1, "ADJUST_BID", phase=2, cfg=self.cfg))
        self.assertTrue(policy.agent_may_execute(1, "ADJUST_BID", phase=3, cfg=self.cfg))

    def test_level2_agent_execution_needs_explicit_whitelist(self):
        cfg = core.deep_merge(self.cfg, {})
        self.assertFalse(policy.agent_may_execute(2, "ADJUST_PRICE", phase=4, cfg=cfg))
        cfg["autonomy"]["l2_auto_actions"] = ["ADJUST_PRICE"]
        self.assertTrue(policy.agent_may_execute(2, "ADJUST_PRICE", phase=4, cfg=cfg))

    def test_guardrail_blocks_protected_term(self):
        cfg = core.deep_merge(self.cfg, {"ads": {"protected_terms": ["krishna"]}})
        ok, why = policy.guardrail_check("ADD_NEGATIVE_KEYWORDS", {"terms": ["krishna ethnic kurta"]}, cfg)
        self.assertFalse(ok)
        self.assertIn("protected", why)

    def test_guardrail_blocks_unbounded_unknown_action(self):
        ok, _ = policy.guardrail_check("SOMETHING_NEW", {}, self.cfg)
        self.assertFalse(ok)


class TestPriority(unittest.TestCase):
    def test_higher_impact_scores_higher(self):
        low = priority.score(impact=2, urgency=5, confidence=0.8, effort=3)
        high = priority.score(impact=9, urgency=9, confidence=0.9, effort=2)
        self.assertLess(low, high)

    def test_severity_floor_never_relaxes_priority(self):
        s = priority.score(impact=1, urgency=1, confidence=0.5, effort=9)  # would bucket to P4
        p = priority.bucket(s, severity_floor=1)
        self.assertEqual(p, 1)

    def test_severity_floor_does_not_worsen_a_naturally_urgent_score(self):
        s = priority.score(impact=10, urgency=10, confidence=1, effort=1)  # naturally P1
        p = priority.bucket(s, severity_floor=2)  # floor is a ceiling on the number, not a demotion
        self.assertEqual(p, 1)


class TestCompliance(unittest.TestCase):
    def test_valid_kurta_set_passes(self):
        row = {"category": "Kurta Sets", "hsn": "620440",
               "attrs": {"color": "Blue", "size": "M", "fabric": "Cotton", "pattern": "Printed",
                         "sleeve_type": "3/4 Sleeve", "neck_style": "Round Neck", "occasion": "Festive",
                         "bottom_type": "Palazzo"}}
        self.assertEqual(validate_listing(row, core.DEFAULT_CONFIG), [])

    def test_missing_hsn_fails(self):
        row = {"category": "Kurta Sets", "hsn": "", "attrs": {}}
        errs = validate_listing(row, core.DEFAULT_CONFIG)
        self.assertTrue(any(e["code"] == "HSN_MISSING" for e in errs))

    def test_synonym_size_gets_a_suggestion(self):
        row = {"category": "Kurta Sets", "hsn": "620440",
               "attrs": {"color": "Blue", "size": "XXXL", "fabric": "Cotton", "pattern": "Printed",
                         "sleeve_type": "3/4 Sleeve", "neck_style": "Round Neck", "occasion": "Festive",
                         "bottom_type": "Palazzo"}}
        errs = validate_listing(row, core.DEFAULT_CONFIG)
        bad = next(e for e in errs if e["field"] == "size")
        self.assertEqual(bad["suggestion"], "3XL")


class TestIngest(unittest.TestCase):
    def test_percentage_string_becomes_fraction(self):
        self.assertAlmostEqual(ingest.frac("87%"), 0.87)
        self.assertAlmostEqual(ingest.frac("0.87"), 0.87)
        self.assertIsNone(ingest.frac(""))

    def test_currency_string_becomes_number(self):
        self.assertEqual(ingest.num("₹1,899"), 1899.0)
        self.assertIsNone(ingest.num("N/A"))

    def test_unknown_listing_columns_become_attributes(self):
        c = ingest.canon("listings", {"SKU": "X1", "Fabric": "Cotton", "Random Column": "abc"})
        self.assertEqual(c["sku"], "X1")
        self.assertEqual(c["_attrs"]["fabric"], "Cotton")
        self.assertEqual(c["_attrs"]["random_column"], "abc")


class TestFullLifecycle(unittest.TestCase):
    """Seed the demo account, run a cycle, execute a task, simulate the fix, verify, measure."""

    def setUp(self):
        self.conn, self.aid = seeded_conn()
        self.director = AccountDirector(self.conn, self.aid)

    def test_first_cycle_raises_the_planted_issues_with_no_errors(self):
        s = self.director.run_cycle()
        self.assertEqual(s["errors"], {})
        self.assertGreater(s["new_issues"], 15)  # demo.py plants problems in every department
        self.assertEqual(s["tasks_created"], s["new_issues"])

    def test_dashboard_and_briefs_do_not_raise(self):
        self.director.run_cycle()
        d = reporting.dashboard(self.conn, self.aid)
        self.assertIn("tiles", d)
        self.assertTrue(reporting.daily_brief_md(self.conn, self.aid))
        self.assertTrue(reporting.weekly_report_md(self.conn, self.aid))

    def test_reject_ignores_the_issue_on_recurrence(self):
        self.director.run_cycle()
        open_ = core.rows(self.conn, "SELECT * FROM tasks WHERE account_id=? AND status IN ('pending_approval','pending_decision')", (self.aid,))
        t = open_[0]
        self.director.reject(t["id"], note="not now")
        iss = core.row(self.conn, "SELECT status FROM issues WHERE id=?", (t["issue_id"],))
        self.assertEqual(iss["status"], "ignored")
        self.director.run_cycle()  # issue should still be findable (data unchanged) but must stay ignored
        iss2 = core.row(self.conn, "SELECT status FROM issues WHERE id=?", (t["issue_id"],))
        self.assertEqual(iss2["status"], "ignored")

    def test_execute_then_simulated_fix_then_verify_then_measure(self):
        self.director.run_cycle()
        # the suppressed listing is a clean level-2, single-cause case
        t = core.row(self.conn, "SELECT * FROM tasks WHERE account_id=? AND action_type='FIX_SUPPRESSION'", (self.aid,))
        self.director.approve(t["id"])
        r = self.director.execute(t["id"])
        self.assertTrue(r["ok"])

        demo.simulate_fixes(self.conn, core.get_account(self.conn, self.aid))
        s = self.director.run_cycle()
        self.assertGreaterEqual(s["verified"], 1)

        done = self.director.measure(force=True)
        self.assertIn(t["id"], done)
        closed = core.row(self.conn, "SELECT status, outcome FROM tasks WHERE id=?", (t["id"],))
        self.assertEqual(closed["status"], "closed")
        self.assertEqual(closed["outcome"], "improved")

    def test_phase1_never_lets_an_agent_execute(self):
        s = self.director.run_cycle()
        self.assertEqual(s["agent_executed"], 0)

    def test_phase4_lets_level1_agent_actions_through(self):
        core.set_account_config(self.conn, self.aid, {"phase": 4})
        self.director = AccountDirector(self.conn, self.aid)
        s = self.director.run_cycle()
        self.assertGreater(s["agent_executed"], 0)
        # a level-2 action must still NOT auto-execute unless explicitly whitelisted
        l2 = core.row(self.conn, "SELECT status FROM tasks WHERE account_id=? AND autonomy_level=2 LIMIT 1", (self.aid,))
        self.assertNotEqual(l2["status"], "executed")

    def test_size_chart_event_handoff_from_cx_to_catalogue(self):
        """Brief section 10: a CX return-reason pattern should hand off to Catalogue."""
        s = self.director.run_cycle()
        self.assertGreater(s["events"], 0)
        sizeissue = core.row(self.conn, "SELECT * FROM issues WHERE account_id=? AND type='size_chart_missing'", (self.aid,))
        self.assertIsNotNone(sizeissue, "CX's returns.pattern event should have produced a Catalogue size-chart issue")

    def test_precheck_matches_the_live_validator(self):
        account = core.get_account(self.conn, self.aid)
        bad_row = {"sku": "X", "category": "Kurta Sets", "hsn": "62", "fabric": ""}
        result = ingest.precheck_rows([bad_row], account["config"])
        self.assertEqual(result["failed"], 1)


class TestMetrics(unittest.TestCase):
    def test_compute_returns_none_for_unknown_metric(self):
        conn, aid = seeded_conn()
        account = core.get_account(conn, aid)
        ctx = Ctx(conn, account)
        self.assertIsNone(metrics.compute(ctx, "not_a_real_metric", "x"))

    def test_stock_cover_days_matches_inventory_row(self):
        conn, aid = seeded_conn()
        account = core.get_account(conn, aid)
        ctx = Ctx(conn, account)
        row = core.row(conn, "SELECT sku, stock, avg_daily_sales FROM inventory WHERE account_id=? LIMIT 1", (aid,))
        expected = round(row["stock"] / row["avg_daily_sales"], 1)
        self.assertEqual(metrics.compute(ctx, "stock_cover_days", row["sku"]), expected)


if __name__ == "__main__":
    unittest.main()
