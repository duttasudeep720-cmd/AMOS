"""REPORTING: the Account Manager dashboard (brief, section 21) and the daily / weekly briefs."""
import datetime as dt

from . import core, coverage, evidence
from .engines import priority, tasks, learning
from .ingest import KINDS


def _pct(a, b):
    return None if not b else (a - b) / b


_SYMBOLS = {"INR": "₹", "USD": "$", "GBP": "£", "EUR": "€"}


def _fmt_money(x, currency="INR"):
    """Format an amount in the ACCOUNT's own currency (never converted). INR renders exactly as before;
    codes without a well-known symbol (e.g. AED) render as 'AED 1,234'."""
    code = (currency or "INR").upper()
    return "{}{:,.0f}".format(_SYMBOLS.get(code, code + " "), x or 0)


def _fmt_inr(x):
    return _fmt_money(x, "INR")


def _dept_status(issues, depts, types=None):
    ii = [i for i in issues if i["department"] in depts and i["kind"] == "issue" and (not types or i["type"] in types)]
    if not ii:
        return "green", 0
    p = min(i["priority"] for i in ii)
    return ("red" if p == 1 else "orange" if p == 2 else "yellow"), len(ii)


def _perf_windows(conn, aid):
    d = core.rows(conn, "SELECT * FROM daily_performance WHERE account_id=? ORDER BY date", (aid,))
    return d


def _sum(rows, k):
    return sum((r[k] or 0) for r in rows)


def dashboard(conn, account_id):
    acct = core.get_account(conn, account_id)
    cur = acct.get("currency") or "INR"
    issues = core.rows(conn, "SELECT * FROM issues WHERE account_id=? AND status='open'", (account_id,))
    perf = _perf_windows(conn, account_id)
    tiles = []

    def tile(key, label, status, headline, detail=""):
        tiles.append({"key": key, "label": label, "status": status, "headline": headline, "detail": detail})

    st, n = _dept_status(issues, ["account_health"])
    tile("health", "Account health", st, "Healthy" if not n else f"{n} issue{'s' if n > 1 else ''}",
         "" if not n else next(i["title"] for i in sorted(issues, key=lambda i: i["priority"]) if i["department"] == "account_health"))

    if perf:
        last, prev7 = perf[-1], perf[-8:-1]
        avg = _sum(prev7, "sales") / len(prev7) if prev7 else None
        chg = _pct(last["sales"], avg) if avg else None
        arrow = "" if chg is None else ("↑" if chg >= 0 else "↓") + f" {abs(chg) * 100:.0f}%"
        st, _ = _dept_status(issues, ["analytics"])
        tile("sales", "Sales", st, f"{_fmt_money(last['sales'], cur)} {arrow}".strip(), f"{last['date']} vs 7-day average")
        w = perf[-7:]
        acos = _sum(w, "ad_spend") / _sum(w, "ad_sales") if _sum(w, "ad_sales") else None
        tacos = _sum(w, "ad_spend") / _sum(w, "sales") if _sum(w, "sales") else None
        st, n = _dept_status(issues, ["advertising"])
        tile("ads", "Advertising", st, f"TACOS {tacos * 100:.1f}% · ACOS {acos * 100:.1f}%" if tacos and acos else "No ad data",
             f"last 7 days · {n} advertising issue(s)" if n else "last 7 days")
    else:
        tile("sales", "Sales", "grey", "No data", "Upload daily_performance")
        st, n = _dept_status(issues, ["advertising"])
        tile("ads", "Advertising", st if n else "grey", f"{n} issue(s)" if n else "No ad issues", "")

    st, n = _dept_status(issues, ["inventory"])
    tile("inventory", "Inventory", st, "Healthy" if not n else f"{n} SKU{'s' if n > 1 else ''} at risk", "")
    st, n = _dept_status(issues, ["catalogue", "compliance"])
    tile("catalogue", "Catalogue", st, "Clean" if not n else f"{n} listing issue{'s' if n > 1 else ''}", "content + compliance")
    st, n = _dept_status(issues, ["operations"])
    tile("orders", "Orders", st, "Normal" if not n else "Late shipments", "" if not n else next(i["title"] for i in issues if i["department"] == "operations"))
    st, n = _dept_status(issues, ["cx"])
    tile("returns", "Returns", st, "Normal" if not n else f"{n} high-return SKU{'s' if n > 1 else ''}", "")
    st, n = _dept_status(issues, ["pricing"])
    tile("pricing", "Pricing", st, "Normal" if not n else f"{n} pricing issue{'s' if n > 1 else ''}", "")
    opp = [i for i in issues if i["kind"] == "opportunity"]
    tile("opportunities", "Opportunities", "blue" if opp else "grey", str(len(opp)), "growth and savings ideas")

    active = tasks.list_tasks(conn, account_id, "active")
    buckets = {p: sum(1 for t in active if t["priority"] == p) for p in (1, 2, 3, 4)}
    src = {r["kind"]: r for r in core.rows(conn, "SELECT kind, rows, ingested_at FROM data_sources WHERE account_id=?", (account_id,))}
    cov = coverage.get_account_coverage(conn, account_id)
    return {
        "account": {"id": acct["id"], "client": acct["client_name"], "marketplace": acct["marketplace"], "store": acct["store"],
                    "phase": acct["config"]["phase"], "mode": acct["config"]["execution"]["mode"], "currency": cur},
        "tiles": tiles, "buckets": buckets, "bucket_labels": priority.LABELS,
        "awaiting_approval": sum(1 for t in active if t["status"] in ("pending_approval", "pending_decision")),
        "open_tasks": len(active), "tasks": active,
        "data_sources": [{"kind": k, "rows": src[k]["rows"] if k in src else None,
                          "ingested_at": src[k]["ingested_at"] if k in src else None} for k in KINDS],
        # data coverage (informational, additive - see amos/coverage.py): per-kind availability/
        # freshness plus any resulting analysis limitations. Never affects the tiles/tasks above.
        "data_coverage": cov,
        "coverage_limitations": coverage.limitations(cov),
    }


def issues_list(conn, account_id, status="open", with_evidence=True):
    out = core.rows(conn, "SELECT * FROM issues WHERE account_id=? AND status=? ORDER BY priority, score DESC", (account_id, status))
    for i in out:
        i["evidence"] = core.loads(i.pop("evidence_json"), {})
        i["recommendation"] = core.loads(i.pop("recommendation_json"), {})
        i["metric"] = core.loads(i.pop("metric_json"), None)
        if with_evidence:
            # Structured Evidence layer (amos/evidence.py) - additive: `evidence` above is left
            # exactly as before for anything already reading it; `evidence_items` is the new,
            # structured, per-fact list for the dashboard/API to render.
            i["evidence_items"] = evidence.get_issue_evidence(conn, i["id"])
    return out


def daily_brief_md(conn, account_id):
    d = dashboard(conn, account_id)
    a = d["account"]
    perf = _perf_windows(conn, account_id)
    lines = [f"# Daily brief - {a['client']} ({a['marketplace']})", f"_{core.today().isoformat()}_", ""]
    lines.append("## What happened")
    if perf:
        last, prev = perf[-1], perf[-8:-1]
        avg = _sum(prev, "sales") / len(prev) if prev else None
        chg = _pct(last["sales"], avg)
        lines.append(f"- Sales on {last['date']}: **{_fmt_money(last['sales'], a.get('currency'))}**" + (f" ({chg * 100:+.0f}% vs 7-day average)" if chg is not None else ""))
        lines.append(f"- Orders: {last['orders']} · Sessions: {last['sessions']} · Ad spend: {_fmt_money(last['ad_spend'], a.get('currency'))}")
        if last["ad_sales"] and last["sales"]:
            lines.append(f"- Day ACOS {last['ad_spend'] / last['ad_sales'] * 100:.1f}% · TACOS {last['ad_spend'] / last['sales'] * 100:.1f}%")
    else:
        lines.append("- No daily performance data uploaded yet.")
    lines += ["", "## Today's tasks"]
    b = d["buckets"]
    lines.append(f"Critical {b[1]} · High {b[2]} · Medium {b[3]} · Monitor {b[4]}   |   awaiting approval/decision: {d['awaiting_approval']}")
    for label_p in (1, 2, 3):
        ts = [t for t in d["tasks"] if t["priority"] == label_p and t["status"] in ("pending_approval", "pending_decision", "human_only", "ready")]
        if ts:
            lines += ["", f"### {priority.LABELS[label_p]}"]
            lines += [f"- [#{t['id']}] {t['title']}  _(L{t['autonomy_level']}, {t['department']}, due {t['due_date']})_" for t in ts[:12]]
    since = (dt.datetime.now() - dt.timedelta(days=1)).isoformat()
    ver = core.rows(conn, "SELECT id,title FROM tasks WHERE account_id=? AND verified_at>=?", (account_id, since))
    if ver:
        lines += ["", "## Verified fixed in the last 24h"] + [f"- [#{t['id']}] {t['title']}" for t in ver]
    opps = [t for t in d["tasks"] if t["priority"] == 4]
    if opps:
        lines += ["", "## Monitor / opportunities"] + [f"- {t['title']}" for t in opps[:8]]
    if d["coverage_limitations"]:
        lines += ["", "## Data coverage"] + [f"- {lim['message']}" for lim in d["coverage_limitations"]]
    return "\n".join(l for l in lines if l is not None)


def weekly_report_md(conn, account_id):
    d = dashboard(conn, account_id)
    a = d["account"]
    perf = _perf_windows(conn, account_id)
    cur, prev = perf[-7:], perf[-14:-7]
    lines = [f"# Weekly client report - {a['client']} ({a['marketplace']})", f"_week ending {perf[-1]['date'] if perf else core.today().isoformat()}_", ""]
    if cur:
        lines += ["## Performance (last 7 days vs previous 7)", "", "| Metric | This week | Previous | Change |", "|---|---|---|---|"]
        for label, k in (("Sales", "sales"), ("Orders", "orders"), ("Sessions", "sessions"), ("Ad spend", "ad_spend")):
            c, p = _sum(cur, k), _sum(prev, k)
            ch = _pct(c, p)
            f = (lambda v: _fmt_money(v, a.get("currency"))) if k in ("sales", "ad_spend") else (lambda v: f"{v:,.0f}")
            lines.append(f"| {label} | {f(c)} | {f(p) if prev else '-'} | {'-' if ch is None else f'{ch * 100:+.0f}%'} |")
        for label, num, den in (("ACOS", "ad_spend", "ad_sales"), ("TACOS", "ad_spend", "sales")):
            c = _sum(cur, num) / _sum(cur, den) if _sum(cur, den) else None
            p = _sum(prev, num) / _sum(prev, den) if prev and _sum(prev, den) else None
            lines.append(f"| {label} | {'-' if c is None else f'{c * 100:.1f}%'} | {'-' if p is None else f'{p * 100:.1f}%'} | |")
    since = (dt.datetime.now() - dt.timedelta(days=7)).isoformat()
    made = core.row(conn, "SELECT COUNT(*) n FROM tasks WHERE account_id=? AND created_at>=?", (account_id, since))["n"]
    done = core.rows(conn, "SELECT outcome, COUNT(*) n FROM tasks WHERE account_id=? AND closed_at>=? GROUP BY outcome", (account_id, since))
    lines += ["", "## Work done", f"- Tasks raised: {made}", f"- Open tasks now: {d['open_tasks']} (awaiting approval/decision: {d['awaiting_approval']})"]
    for r in done:
        lines.append(f"- Closed as '{r['outcome']}': {r['n']}")
    meas = core.rows(conn, """SELECT t.title, m.metric, m.before_value, m.after_value, m.verdict FROM measurements m
        JOIN tasks t ON t.id=m.task_id WHERE t.account_id=? AND m.measured_at>=? AND m.metric IS NOT NULL""", (account_id, since))
    if meas:
        lines += ["", "## Measured results"]
        lines += [f"- {m['title']}: {m['metric']} {m['before_value']} -> {m['after_value']} (**{m['verdict']}**)" for m in meas]
    st = learning.stats(conn, account_id)
    if st:
        lines += ["", "## What the system has learned", "", "| Action | Runs | Improved | No change | Worse | Rejected |", "|---|---|---|---|---|---|"]
        for r in st:
            lines.append(f"| {r['action_type']} | {r['n']} | {r['improved'] or 0} | {r['no_change'] or 0} | {r['worse'] or 0} | {r['rejected'] or 0} |")
    lines += ["", "## Still open (top priorities)"]
    lines += [f"- P{t['priority']} {t['title']}" for t in d["tasks"][:10]]
    return "\n".join(lines)
