"""AMOS - Desiretech Account Management Operating System.

A hierarchical Amazon (India-first) account-management system modelled on how a real e-commerce
agency works, per the architecture brief in HANDOVER.md:

    Account Director -> Department Managers -> Task Agents (amos/org.py, the organisational
    hierarchy: who owns what) feeding a shared execution pipeline (the "engines", who
    detects/decides/executes/verifies):

        DETECT -> ANALYZE -> DIAGNOSE -> RECOMMEND -> APPROVE -> EXECUTE -> VERIFY -> MEASURE -> LEARN

Package map:
    core.py                sqlite schema, connection, small shared helpers (today(), now(), dumps())
    skills/                the Tools layer: pure fn(ctx) -> list[Finding] detection functions
    org.py                 the organisational hierarchy (departments/agents) built from skills/
    engines/               the execution hierarchy: exception, priority, policy, tasks, execution,
                            verification, learning
    director.py            AccountDirector - runs one full cycle for one account through org + engines
    ingest.py              turns raw exports (CSV/XLSX/dicts) into the sqlite tables skills read
    reporting.py           daily/weekly briefs and the dashboard's aggregate views
    demo.py                seeds a realistic demo account and (optionally) simulates fixes over time
    cli.py / server.py     `python -m amos ...` commands, and the stdlib dashboard server
    web/index.html         the static single-page dashboard server.py serves at "/"

See HANDOVER.md for status/history and ARCHITECTURE.md for the full brief this implements.
"""
__version__ = "1.0.0"
