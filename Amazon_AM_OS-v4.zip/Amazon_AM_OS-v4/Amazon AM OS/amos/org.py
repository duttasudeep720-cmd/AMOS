"""ORGANISATIONAL HIERARCHY  (who is responsible for what).

    Account Director  ->  Department Manager  ->  Task Agents  ->  Skills

The EXECUTION hierarchy (who detects / decides / executes / verifies) lives in the engines and director.
An agent with no skills is "planned": it appears in the org chart but does nothing yet. To activate it,
write a skill (amos/skills/*.py) and add its name to the agent's skill list below. No other change needed.

Every agent has the same anatomy (brief, section 18):
    Input, Knowledge, Rules, Tools(skills), Reasoning, Decision, Action, Verification, Output
"""
from dataclasses import dataclass, field

from .skills import SKILLS


@dataclass
class Agent:
    name: str
    skills: tuple = ()

    @property
    def implemented(self):
        return bool(self.skills)

    def anatomy(self):
        src = sorted({s for k in self.skills for s in SKILLS[k].sources})
        return {
            "input": src or ["(planned)"],
            "knowledge": "account config (targets, thresholds) + issue history + learning stats",
            "rules": "guardrails in amos/engines/policy.py + per-account config",
            "tools": list(self.skills),
            "reasoning": "skill logic: detect > analyse > diagnose > recommend",
            "decision": "Priority engine + Approval policy (autonomy level 0-4)",
            "action": "Execution engine (manual, dry-run or live connector)",
            "verification": "Verification engine (issue must clear on fresh data)",
            "output": "Finding -> Issue -> Task -> Result -> Learning",
        }


@dataclass
class Department:
    key: str
    name: str
    manager: str
    agents: list = field(default_factory=list)
    phase: str = "V1"      # V1 = active now, later = planned

    @property
    def skills(self):
        return [s for a in self.agents for s in a.skills]


def A(name, *skills):
    return Agent(name, tuple(skills))


ORG = [
    Department("account_health", "Account Health", "Account Health Manager", [
        A("Suppression Agent", "detect_suppressed_listings"),
        A("Buy Box Agent", "check_buy_box"),
        A("Performance Agent", "check_account_health_metrics"),
        A("Policy Agent"), A("Rating Agent"), A("Account Notification Agent"), A("Risk Detection Agent")]),
    Department("catalogue", "Catalogue & Content", "Catalogue Manager", [
        A("Listing Audit Agent", "audit_listing_content"),
        A("Size & Fit Agent", "size_chart_from_returns"),
        A("Product Discovery Agent"), A("Title Agent"), A("Bullet Agent"), A("Description Agent"),
        A("Backend Keyword Agent"), A("Image Agent"), A("A+ Agent"), A("Variation Agent"),
        A("Attribute Agent"), A("Category Agent"), A("Catalogue QA Agent")]),
    Department("advertising", "Advertising", "Advertising Manager", [
        A("Search Term Agent", "detect_wasted_ad_spend", "harvest_converting_terms"),
        A("ACOS Agent", "detect_high_acos_campaigns"),
        A("Budget Agent", "find_budget_constrained_winners"),
        A("Campaign Audit Agent"), A("Keyword Research Agent"), A("Campaign Structure Agent"), A("Bid Agent"),
        A("Placement Agent"), A("Product Targeting Agent"), A("Competitor Targeting Agent"),
        A("TACOS Agent"), A("ROAS Agent"), A("Advertising QA Agent")]),
    Department("pricing", "Pricing", "Pricing Manager", [
        A("Margin Agent", "detect_price_below_floor"),
        A("Competitor Price Agent"), A("Buy Box Price Agent"), A("MRP Agent"), A("Discount Agent"),
        A("Price Change Detection Agent"), A("Pricing QA Agent")]),
    Department("inventory", "Inventory", "Inventory Manager", [
        A("Stock Monitoring Agent", "detect_stockout_risk"),
        A("Overstock Agent", "detect_overstock"),
        A("Replenishment Agent"), A("FBA Inventory Agent"), A("Slow Moving Agent"),
        A("Restock Recommendation Agent"), A("Inventory QA Agent")]),
    Department("operations", "Orders & Operations", "Operations Manager", [
        A("Late Shipment Agent", "detect_late_shipments"),
        A("Order Monitoring Agent"), A("Fulfilment Agent"), A("Cancellation Agent"), A("SLA Agent"),
        A("Shipment Agent"), A("FBA Issue Agent"), A("Operations QA Agent")]),
    Department("cx", "Returns & Customer Experience", "CX Manager", [
        A("Return Analysis Agent", "analyze_returns"),
        A("Return Reason Agent"), A("Refund Agent"), A("Customer Complaint Agent"), A("Product Defect Agent"),
        A("Review Monitoring Agent"), A("Rating Analysis Agent"), A("CX Improvement Agent")]),
    Department("growth", "Promotions & Growth", "Growth Manager", [
        A("Deal Agent"), A("Coupon Agent"), A("Promotion Agent"), A("Event Calendar Agent"), A("Seasonal Agent"),
        A("New Product Agent"), A("Cross Sell Agent"), A("Growth Opportunity Agent")]),
    Department("analytics", "Analytics & BI", "BI Manager", [
        A("Sales Analyst", "detect_sales_anomaly"),
        A("Traffic Analyst"), A("Conversion Analyst"), A("Profit Analyst"), A("Advertising Analyst"),
        A("Product Analyst"), A("Customer Analyst"), A("Trend Analyst"), A("Forecast Agent")]),
    Department("compliance", "Compliance & Marketplace Admin", "Compliance Manager", [
        A("Product Compliance Agent", "validate_catalogue"),
        A("Policy Agent (Compliance)"), A("Documentation Agent"), A("Tax/HSN Agent"), A("Brand Registry Agent"),
        A("Restricted Product Agent"), A("IP Agent"), A("Compliance QA Agent")]),
    Department("expansion", "Expansion / New Marketplace", "Expansion Manager", [], phase="later"),
    Department("brand", "Brand & Creative", "Brand Manager", [], phase="later"),
    Department("finance", "Finance / Reconciliation", "Finance Manager", [], phase="later"),
    Department("competitor", "Competitor Intelligence", "Competitor Intelligence Manager", [], phase="later"),
]

# sanity: every skill named in the org exists, and every registered skill is owned by exactly one agent
_owned = [s for d in ORG for s in d.skills]
assert all(s in SKILLS for s in _owned), [s for s in _owned if s not in SKILLS]
assert len(_owned) == len(set(_owned)), "a skill is owned by two agents"
assert set(SKILLS) == set(_owned), f"unowned skills: {set(SKILLS) - set(_owned)}"

_SKILL_OWNER = {s: (d, a) for d in ORG for a in d.agents for s in a.skills}


def owner_of(skill_name):
    return _SKILL_OWNER[skill_name]


def department(key):
    return next(d for d in ORG if d.key == key)


def describe():
    return {
        "director": "Account Director (one per client account)",
        "departments": [{
            "key": d.key, "name": d.name, "manager": d.manager, "phase": d.phase,
            "agents": [{"name": a.name, "skills": list(a.skills), "implemented": a.implemented,
                        "anatomy": a.anatomy() if a.implemented else None} for a in d.agents]} for d in ORG],
        "skills": {k: {"sources": list(v.sources), "topics": list(v.topics), "description": v.description}
                   for k, v in SKILLS.items()},
    }
