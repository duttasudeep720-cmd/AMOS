"""DEMO DATA for a fictional client (Krishna Enterprises, Amazon India, ethnic wear).

`seed()` writes realistic sample CSVs (they double as upload templates) and ingests them through the
normal file-ingestion path. Problems are planted on purpose so every department has something to find.
`simulate_fixes()` fakes the world reacting to executed tasks - DEMO ONLY - so the verify > measure > learn
loop can be shown without a real marketplace.
"""
import csv
import datetime as dt
import os
import random

from . import core, ingest
from .skills.compliance import rules_for

CLIENT, STORE = "Krishna Enterprises", "Krishna Ethnic"
GOOD_TITLE = ("Krishna Ethnic Women's Cotton Kurta Set with Palazzo and Dupatta, Printed 3-Piece Ethnic Wear "
              "for Festive, Party and Daily Wear")


def _listing(sku, cat, units, price, cost, mrp=None, **kw):
    attrs = dict(color="Blue", size="M", fabric="Cotton", pattern="Printed", sleeve_type="3/4 Sleeve", neck_style="Round Neck",
                 occasion="Festive", bottom_type="Palazzo", size_chart="Yes")
    attrs.update(kw.pop("attrs", {}))
    d = dict(sku=sku, asin="B0" + sku.replace("-", "")[-8:].upper().ljust(8, "X"), title=GOOD_TITLE, brand="Krishna Ethnic",
             category=cat, bullet_count=5, description_len=520, image_count=8, has_aplus="yes", price=price, mrp=mrp or round(price * 1.9),
             cost=cost, fee_pct=0.18, shipping_cost=50, hsn="620440", status="active", status_reason="", buy_box_pct=0.9,
             buy_box_pct_prev=0.9, buybox_price="", sessions=max(int(units * 7.5), 200), conversion_pct=0.12, units_30d=units)
    d.update(kw)
    d.update(attrs)
    return d


def build_dataset(today):
    rnd = random.Random(42)
    L = [
        _listing("KE-KS-001", "Kurta Sets", 420, 899, 330, sessions=3400, conversion_pct=0.125),                       # hero, will run low on stock
        _listing("KE-KS-002", "Kurta Sets", 310, 1099, 420, sessions=2800, conversion_pct=0.055, bullet_count=3, image_count=4,
                 title="Krishna Kurta Set Blue", has_aplus="", description_len=150, attrs={"size_chart": ""}),   # low conv + size returns
        _listing("KE-KS-003", "Kurta Sets", 150, 599, 300),                                                            # price below floor
        _listing("KE-KS-004", "Kurta Sets", 60, 749, 290, hsn="62", attrs={"size": "XXXL", "fabric": ""}),            # validation: size, HSN, fabric
        _listing("KE-KS-005", "Kurta Sets", 45, 799, 300, hsn="", attrs={"sleeve_type": "Three Quarter"}),            # validation: HSN + sleeve
        _listing("KE-KS-006", "Kurta Sets", 120, 849, 320, status="suppressed",
                 status_reason="Missing required attribute: Country of Origin"),                                        # suppression
        _listing("KE-KS-007", "Kurta Sets", 200, 749, 260, buy_box_pct=0.21, buy_box_pct_prev=0.87, buybox_price=719),  # buy box: matchable
        _listing("KE-KS-008", "Kurta Sets", 90, 899, 330, buy_box_pct=0.30, buy_box_pct_prev=0.75, buybox_price=640),   # buy box: NOT safely matchable
        _listing("KE-KS-009", "Kurta Sets", 110, 949, 340),
        _listing("KE-KS-010", "Kurta Sets", 24, 699, 300),                                                             # overstock
        _listing("KE-KU-001", "Kurtis", 380, 549, 200, sessions=2900),
        _listing("KE-KU-002", "Kurtis", 70, 999, 300, mrp=899),                                                        # price above MRP
        _listing("KE-KU-003", "Kurtis", 260, 499, 190),                                                                # low stock (not hero)
        _listing("KE-KU-004", "Kurtis", 55, 599, 220, bullet_count=4, description_len=210),                            # minor content gaps
        _listing("KE-KU-005", "Kurtis", 60, 479, 180),                                                                 # defect returns
        _listing("KE-KU-006", "Kurtis", 95, 529, 195),
        _listing("KE-KU-007", "Kurtis", 80, 579, 210),
        _listing("KE-KU-008", "Kurtis", 70, 559, 200),
    ]
    inv = []
    for l in L:
        adr = round(l["units_30d"] / 30, 2)
        stock, lead = int(adr * 45), 10
        if l["sku"] == "KE-KS-001":
            stock, lead = 95, 12
        if l["sku"] == "KE-KU-003":
            stock = 70
        if l["sku"] == "KE-KS-010":
            stock = 400
        inv.append(dict(sku=l["sku"], asin=l["asin"], stock=stock, inbound=0, avg_daily_sales=adr, lead_time_days=lead,
                        snapshot_date=today.isoformat()))

    # ---- advertising: (campaign, budget, [(term, match, clicks, spend, orders, sales)]) ------------------
    T = lambda t, m, c, s, o, sa: dict(term=t, match=m, clicks=c, spend=s, orders=o, sales=sa)  # noqa: E731
    camps = [
        ("SP | Kurta Sets | Auto", 800, [
            T("kurta set for women party wear", "BROAD", 34, 612, 0, 0), T("palazzo set cheap", "BROAD", 41, 705, 0, 0),
            T("kurti under 300", "BROAD", 28, 486, 0, 0), T("anarkali gown", "BROAD", 22, 402, 0, 0),
            T("sharara set", "BROAD", 19, 371, 0, 0),
            T("cotton kurta set with dupatta", "BROAD", 30, 420, 6, 5400), T("kurta palazzo set women", "BROAD", 22, 300, 4, 3600),
            T("(other terms)", "EXACT", 150, 1904, 10, 6000)]),
        ("SP | Kurta Sets | Broad", 600, [
            T("kurta set", "BROAD", 25, 410, 0, 0), T("women kurta sets", "BROAD", 60, 900, 3, 3000),
            T("(other terms)", "EXACT", 190, 2590, 4, 3500)]),
        ("SP | Kurta Sets | Exact - Hero", 400, [
            T("cotton kurta set women", "EXACT", 120, 1500, 22, 10500), T("(other terms)", "EXACT", 80, 1100, 9, 5500)]),
        ("SP | Kurtis | Phrase", 500, [
            T("kurti for women", "PHRASE", 90, 1300, 9, 3900), T("(other terms)", "EXACT", 110, 1500, 12, 4300)]),
        ("SP | Kurtis | Auto", 500, [
            T("cotton kurti under 500", "BROAD", 20, 250, 3, 1500), T("(other terms)", "EXACT", 100, 1250, 14, 7000)]),
        ("SB | Brand Defense", 200, [
            T("krishna ethnic kurta", "EXACT", 40, 320, 0, 0), T("(other terms)", "EXACT", 45, 380, 20, 5200)]),
    ]
    terms, campaigns = [], []
    for name, budget, ts in camps:
        for t in ts:
            terms.append({"Campaign Name": name, "Ad Group Name": "AG1", "Customer Search Term": t["term"], "Match Type": t["match"],
                          "Impressions": t["clicks"] * 55, "Clicks": t["clicks"], "Spend": t["spend"],
                          "7 Day Total Sales ": t["sales"], "7 Day Total Orders (#)": t["orders"], "Start Date": (today - dt.timedelta(days=7)).isoformat()})
        campaigns.append(dict(campaign=name, daily_budget=budget, impressions=sum(t["clicks"] for t in ts) * 55, clicks=sum(t["clicks"] for t in ts),
                              spend=sum(t["spend"] for t in ts), sales=sum(t["sales"] for t in ts), orders=sum(t["orders"] for t in ts),
                              days=7, report_date=today.isoformat()))

    # ---- orders ---------------------------------------------------------------------------------------
    orders = []
    skus = [l["sku"] for l in L]
    for i in range(30):
        od = today - dt.timedelta(days=rnd.randint(1, 4))
        orders.append({"amazon-order-id": f"404-{1000000 + i}-{7000000 + i}", "sku": rnd.choice(skus), "order-status": "Shipped",
                       "purchase-date": od.isoformat(), "latest-ship-date": (od + dt.timedelta(days=2)).isoformat(),
                       "shipped_date": (od + dt.timedelta(days=1)).isoformat()})
    for j, delta in enumerate([-2, -1, -1, 0, 0, 0, 0, 1, 1]):
        orders.append({"amazon-order-id": f"404-{2000000 + j}-{8000000 + j}", "sku": rnd.choice(skus), "order-status": "Unshipped",
                       "purchase-date": (today - dt.timedelta(days=3)).isoformat(),
                       "latest-ship-date": (today + dt.timedelta(days=delta)).isoformat(), "shipped_date": ""})

    # ---- returns --------------------------------------------------------------------------------------
    R = []
    for sku, reason, qty in [("KE-KS-002", "Size too small", 28), ("KE-KS-002", "Fit issue - very tight", 8),
                             ("KE-KS-002", "Color different from picture", 6), ("KE-KS-002", "Stitching defect", 5),
                             ("KE-KS-002", "Changed my mind", 8), ("KE-KU-005", "Stitching came apart", 9),
                             ("KE-KS-001", "Size too small", 6), ("KE-KS-001", "Changed my mind", 6)]:
        R.append({"sku": sku, "order_id": "", "reason": reason, "qty": qty, "return_date": (today - dt.timedelta(days=5)).isoformat()})

    # ---- 15 days of performance, last day drops ------------------------------------------------------------
    perf = []
    for k in range(15, 0, -1):
        d = today - dt.timedelta(days=k)
        sales = rnd.randint(47000, 54000)
        sess = rnd.randint(1850, 2050)
        if k == 1:
            sales, sess = 33500, 1650
        perf.append(dict(date=d.isoformat(), sales=sales, orders=int(sess * (0.033 if k == 1 else 0.05)), sessions=sess,
                         ad_spend=rnd.randint(2200, 2500), ad_sales=rnd.randint(8000, 9000)))

    health = [dict(metric="Order Defect Rate", value=0.006, limit_value=0.01, direction="max"),
              dict(metric="Late Dispatch Rate", value=0.034, limit_value=0.04, direction="max"),
              dict(metric="Cancellation Rate", value=0.012, limit_value=0.025, direction="max"),
              dict(metric="Valid Tracking Rate", value=0.985, limit_value=0.95, direction="min")]
    return {"listings": L, "inventory": inv, "campaigns": campaigns, "search_terms": terms, "orders": orders,
            "returns": R, "daily_performance": perf, "health_metrics": health}


def write_csvs(directory, ds):
    os.makedirs(directory, exist_ok=True)
    paths = {}
    for kind, rows in ds.items():
        p = os.path.join(directory, f"{kind}.csv")
        cols = list(dict.fromkeys(k for r in rows for k in r))
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=cols)
            w.writeheader()
            w.writerows(rows)
        paths[kind] = p
    return paths


def seed(conn, sample_dir, phase=1):
    aid = core.create_client_account(conn, CLIENT, "Amazon India", STORE)
    core.set_account_config(conn, aid, {"phase": phase, "ads": {"protected_terms": ["krishna"]}})
    paths = write_csvs(sample_dir, build_dataset(core.today()))
    for kind, p in paths.items():
        ingest.ingest_file(conn, aid, kind, p)
    return aid


# ==================================== fix simulator (DEMO ONLY) ========================================
def _touch(conn, aid, *kinds):
    for k in kinds:
        ingest.touch_source(conn, aid, k)


def _recalc_campaign(conn, aid, camp):
    r = core.row(conn, "SELECT SUM(impressions) i, SUM(clicks) c, SUM(spend) s, SUM(sales) sa, SUM(orders) o FROM ad_search_terms WHERE account_id=? AND campaign=?", (aid, camp))
    core.execute(conn, "UPDATE ad_campaigns SET impressions=?,clicks=?,spend=?,sales=?,orders=? WHERE account_id=? AND campaign=?",
                 (r["i"] or 0, r["c"] or 0, r["s"] or 0, r["sa"] or 0, r["o"] or 0, aid, camp))


def simulate_fixes(conn, account):
    """Apply the effect of every EXECUTED task to the data, then mark the sources as freshly ingested."""
    aid, cfg = account["id"], account["config"]
    applied = []
    for t in core.rows(conn, "SELECT * FROM tasks WHERE account_id=? AND status='executed'", (aid,)):
        a, p = t["action_type"], core.loads(t["action_payload_json"], {})
        sku, camp = p.get("sku"), p.get("campaign") or p.get("source_campaign")
        if a == "ADD_NEGATIVE_KEYWORDS":
            for term in p["terms"]:
                conn.execute("DELETE FROM ad_search_terms WHERE account_id=? AND campaign=? AND search_term=?", (aid, camp, term))
            conn.commit(); _recalc_campaign(conn, aid, camp); _touch(conn, aid, "search_terms", "campaigns")
        elif a == "ADJUST_BID":
            f = 1 + p["change_pct"] / 100
            conn.execute("UPDATE ad_search_terms SET spend=spend*?, sales=sales*0.97 WHERE account_id=? AND campaign=?", (f, aid, camp))
            conn.commit(); _recalc_campaign(conn, aid, camp); _touch(conn, aid, "search_terms", "campaigns")
        elif a == "INCREASE_BUDGET":
            conn.execute("UPDATE ad_campaigns SET daily_budget=daily_budget*?, spend=spend*1.2, sales=sales*1.2 WHERE account_id=? AND campaign=?",
                         (1 + p["change_pct"] / 100, aid, camp))
            conn.commit(); _touch(conn, aid, "campaigns")
        elif a == "ADD_EXACT_KEYWORDS":
            for term in p["terms"]:
                conn.execute("UPDATE ad_search_terms SET match_type='EXACT' WHERE account_id=? AND campaign=? AND search_term=?", (aid, camp, term))
            conn.commit(); _touch(conn, aid, "search_terms")
        elif a == "UPDATE_LISTING_CONTENT":
            l = core.row(conn, "SELECT * FROM listings WHERE account_id=? AND sku=?", (aid, sku))
            attrs = core.loads(l["attrs_json"], {})
            if "size_chart" in p.get("fields", []):
                attrs["size_chart"] = "Yes"
            conn.execute("""UPDATE listings SET title=?, bullet_count=MAX(bullet_count,5), image_count=MAX(image_count,8),
                description_len=MAX(description_len,450), has_aplus=1, conversion_pct=CASE WHEN conversion_pct<0.08 THEN conversion_pct*1.5
                ELSE conversion_pct END, attrs_json=? WHERE account_id=? AND sku=?""", (GOOD_TITLE, core.dumps(attrs), aid, sku))
            conn.execute("UPDATE returns SET qty=MAX(1,qty/3) WHERE account_id=? AND sku=? AND lower(reason) LIKE '%size%'", (aid, sku))
            conn.commit(); _touch(conn, aid, "listings", "returns")
        elif a == "FIX_CATALOGUE_ATTRIBUTES":
            l = core.row(conn, "SELECT * FROM listings WHERE account_id=? AND sku=?", (aid, sku))
            attrs, hsn = core.loads(l["attrs_json"], {}), l["hsn"]
            rules = rules_for(cfg, l["category"]) or {}
            for e in p["errors"]:
                if e["field"] == "hsn":
                    hsn = (rules.get("hsn_prefixes") or ["6204"])[0] + "40"
                elif e["code"] == "MISSING_ATTR":
                    attrs[e["field"]] = (rules.get("allowed_values", {}).get(e["field"]) or ["Cotton"])[0]
                elif e["code"] == "INVALID_VALUE":
                    attrs[e["field"]] = e.get("suggestion") or (rules["allowed_values"][e["field"]][0])
            conn.execute("UPDATE listings SET attrs_json=?, hsn=? WHERE account_id=? AND sku=?", (core.dumps(attrs), hsn, aid, sku))
            conn.commit(); _touch(conn, aid, "listings")
        elif a == "ADD_SIZE_CHART":
            l = core.row(conn, "SELECT attrs_json FROM listings WHERE account_id=? AND sku=?", (aid, sku))
            attrs = core.loads(l["attrs_json"], {}); attrs["size_chart"] = "Yes"
            conn.execute("UPDATE listings SET attrs_json=? WHERE account_id=? AND sku=?", (core.dumps(attrs), aid, sku))
            conn.execute("UPDATE returns SET qty=MAX(1,qty/3) WHERE account_id=? AND sku=? AND lower(reason) LIKE '%size%'", (aid, sku))
            conn.execute("UPDATE returns SET qty=MAX(1,qty/3) WHERE account_id=? AND sku=? AND lower(reason) LIKE '%fit%'", (aid, sku))
            conn.commit(); _touch(conn, aid, "listings", "returns")
        elif a == "ADJUST_PRICE":
            conn.execute("UPDATE listings SET price=?, buy_box_pct=CASE WHEN buy_box_pct<0.6 THEN 0.82 ELSE buy_box_pct END WHERE account_id=? AND sku=?",
                         (p["new_price"], aid, sku))
            conn.commit(); _touch(conn, aid, "listings")
        elif a == "CREATE_REPLENISHMENT":
            conn.execute("UPDATE inventory SET stock=stock+? WHERE account_id=? AND sku=?", (p["qty"], aid, sku)); conn.commit(); _touch(conn, aid, "inventory")
        elif a == "SHIP_ORDERS":
            conn.execute("UPDATE orders SET status='Shipped', shipped_date=? WHERE account_id=? AND status='Unshipped'", (core.today().isoformat(), aid))
            conn.execute("UPDATE health_metrics SET value=0.026 WHERE account_id=? AND metric='Late Dispatch Rate'", (aid,))
            conn.commit(); _touch(conn, aid, "orders", "health_metrics")
        elif a == "INVESTIGATE_ACCOUNT_HEALTH":
            conn.execute("UPDATE health_metrics SET value=0.026 WHERE account_id=? AND metric=?", (aid, p["metric"])); conn.commit(); _touch(conn, aid, "health_metrics")
        elif a == "FIX_SUPPRESSION":
            conn.execute("UPDATE listings SET status='active', status_reason=NULL WHERE account_id=? AND sku=?", (aid, sku)); conn.commit(); _touch(conn, aid, "listings")
        elif a == "RUN_LIQUIDATION_PROMO":
            conn.execute("UPDATE inventory SET stock=stock/4 WHERE account_id=? AND sku=?", (aid, sku)); conn.commit(); _touch(conn, aid, "inventory")
        elif a == "INVESTIGATE_RETURNS":
            conn.execute("UPDATE returns SET qty=1 WHERE account_id=? AND sku=?", (aid, sku)); conn.commit(); _touch(conn, aid, "returns")
        elif a == "INVESTIGATE_SALES_DROP":
            last = core.row(conn, "SELECT * FROM daily_performance WHERE account_id=? ORDER BY date DESC LIMIT 1", (aid,))
            nd = (dt.date.fromisoformat(last["date"]) + dt.timedelta(days=1)).isoformat()
            conn.execute("INSERT OR REPLACE INTO daily_performance(account_id,date,sales,orders,sessions,ad_spend,ad_sales) VALUES(?,?,?,?,?,?,?)",
                         (aid, nd, 51000, 96, 1950, 2300, 8600)); conn.commit(); _touch(conn, aid, "daily_performance")
        # INVESTIGATE_BUYBOX (KS-008) is intentionally NOT simulated: verification must catch an unfixed issue.
        else:
            continue
        applied.append((t["id"], a))
    return applied
