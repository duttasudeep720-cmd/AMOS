"""AMOS dashboard server - stdlib only (http.server), matching HANDOVER.md's tech decisions.

Serves the static dashboard at `/` (amos/web/index.html) and a small JSON API under `/api/*`.
Each request opens its own sqlite connection (cheap - see core.connect) and closes it before
responding, so this is safe for the single-process, low-concurrency use this is designed for
(one agency's internal tool). For real multi-user traffic, put this behind a real WSGI server.
"""
import json
import mimetypes
import os
import re
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

from . import core, coverage, evidence, org, reporting, workqueue
from .director import AccountDirector
from .engines import tasks as tasks_engine

WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")

ROUTES = []  # (method, compiled_path_regex, handler(qs, match, body) -> (status, obj_or_bytes, content_type))


def route(method, pattern):
    rx = re.compile("^" + re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


def _account_id(qs):
    v = qs.get("account_id", qs.get("account"))
    if not v:
        raise ValueError("missing ?account_id=")
    return int(v[0])


def _guard_task(conn, task_id, account_id):
    """A task may only be acted on through the account it belongs to. tasks.approve/reject and
    execution.execute_task look tasks up by id alone, so without this a request carrying the wrong
    ?account_id= would silently act on another account's task. 404, same as a missing task."""
    t = core.row(conn, "SELECT account_id FROM tasks WHERE id=?", (task_id,))
    if not t or t["account_id"] != account_id:
        raise KeyError(f"task {task_id} not found for account {account_id}")


@route("GET", r"/api/accounts")
def r_accounts(conn, qs, m, body):
    return core.rows(conn, "SELECT a.id, c.name AS client, a.marketplace, a.store FROM accounts a JOIN clients c ON c.id=a.client_id ORDER BY a.id")


@route("GET", r"/api/org")
def r_org(conn, qs, m, body):
    return org.describe()


@route("GET", r"/api/dashboard")
def r_dashboard(conn, qs, m, body):
    return reporting.dashboard(conn, _account_id(qs))


@route("GET", r"/api/account/<account_id>/work-queue")
def r_work_queue(conn, qs, m, body):
    """Consolidated AM dashboard payload: overview, state, coverage, work queue, approvals, recent activity.
    Optional ?status=attention|pending_approval|pending_decision|human_only|ready|executed|verified|closed."""
    try:
        aid = int(m["account_id"])
    except ValueError:
        raise ValueError(f"invalid account id '{m['account_id']}'")
    return workqueue.get_work_queue(conn, aid, status=(qs.get("status") or ["attention"])[0])


@route("GET", r"/api/coverage")
def r_coverage(conn, qs, m, body):
    cov = coverage.get_account_coverage(conn, _account_id(qs))
    return {"coverage": cov, "limitations": coverage.limitations(cov)}


@route("GET", r"/api/issues")
def r_issues(conn, qs, m, body):
    return reporting.issues_list(conn, _account_id(qs), status=(qs.get("status") or ["open"])[0])


@route("GET", r"/api/tasks")
def r_tasks(conn, qs, m, body):
    return tasks_engine.list_tasks(conn, _account_id(qs), status=(qs.get("status") or ["active"])[0],
                                    department=(qs.get("department") or [None])[0])


@route("GET", r"/api/tasks/<task_id>")
def r_task_detail(conn, qs, m, body):
    tid = int(m["task_id"])
    if qs.get("account_id") or qs.get("account"):      # optional for backward compatibility; enforced when given
        _guard_task(conn, tid, _account_id(qs))
    d = tasks_engine.task_detail(conn, tid)
    d["am_view"] = workqueue.task_view(conn, tid)       # additive: everything above is exactly as before
    return d


@route("GET", r"/api/issues/<issue_id>/evidence")
def r_issue_evidence(conn, qs, m, body):
    iid = int(m["issue_id"])
    iss = core.row(conn, "SELECT id, title, diagnosis FROM issues WHERE id=?", (iid,))
    if not iss:
        raise KeyError(f"issue {iid} not found")
    iss["evidence"] = evidence.get_issue_evidence(conn, iid)
    return iss


@route("POST", r"/api/tasks/<task_id>/approve")
def r_approve(conn, qs, m, body):
    _guard_task(conn, int(m["task_id"]), _account_id(qs))
    return AccountDirector(conn, _account_id(qs)).approve(int(m["task_id"]), note=(body or {}).get("note", ""))


@route("POST", r"/api/tasks/<task_id>/reject")
def r_reject(conn, qs, m, body):
    _guard_task(conn, int(m["task_id"]), _account_id(qs))
    return AccountDirector(conn, _account_id(qs)).reject(int(m["task_id"]), note=(body or {}).get("note", ""))


@route("POST", r"/api/tasks/<task_id>/execute")
def r_execute(conn, qs, m, body):
    _guard_task(conn, int(m["task_id"]), _account_id(qs))
    return AccountDirector(conn, _account_id(qs)).execute(int(m["task_id"]), note=(body or {}).get("note", ""),
                                                            via=(body or {}).get("via", "manual"))


@route("POST", r"/api/cycle")
def r_cycle(conn, qs, m, body):
    return AccountDirector(conn, _account_id(qs)).run_cycle(trigger="dashboard")


@route("GET", r"/api/brief/daily")
def r_brief_daily(conn, qs, m, body):
    return {"markdown": reporting.daily_brief_md(conn, _account_id(qs))}


@route("GET", r"/api/brief/weekly")
def r_brief_weekly(conn, qs, m, body):
    return {"markdown": reporting.weekly_report_md(conn, _account_id(qs))}


class Handler(BaseHTTPRequestHandler):
    server_version = "AMOS/1.0"

    def log_message(self, fmt, *a):
        pass  # keep stdout clean; audit_log already records every state change

    def _static(self, path):
        if path == "/":
            path = "/index.html"
        fp = os.path.normpath(os.path.join(WEB_DIR, path.lstrip("/")))
        if not fp.startswith(WEB_DIR) or not os.path.isfile(fp):
            return self._json(404, {"error": "not found"})
        ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
        with open(fp, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status, obj):
        data = json.dumps(obj, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _dispatch(self, method, body=None):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        for m, rx, fn in ROUTES:
            if m != method:
                continue
            match = rx.match(parsed.path)
            if match:
                conn = core.connect()
                try:
                    result = fn(conn, qs, match.groupdict(), body)
                    return self._json(200, result)
                except ValueError as e:
                    return self._json(400, {"error": str(e)})
                except KeyError as e:
                    return self._json(404, {"error": str(e.args[0]) if e.args else str(e)})
                except Exception as e:  # noqa: BLE001
                    traceback.print_exc()
                    return self._json(500, {"error": str(e)})
                finally:
                    conn.close()
        if method == "GET" and not parsed.path.startswith("/api/"):
            return self._static(parsed.path)
        self._json(404, {"error": f"no route for {method} {parsed.path}"})

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b""
        try:
            body = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            body = {}
        self._dispatch("POST", body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


def serve(host="127.0.0.1", port=8765):
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"AMOS dashboard: http://{host}:{port}/  (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
