"""LEARNING ENGINE - the MEASURE + LEARN stages of the task lifecycle.

MEASURE recomputes the same metric a Finding was raised on (Finding.metric -> baseline_json on
the task, set when it was executed) once a 'verified' task's measure_due date arrives, and compares
before vs after using that metric's own "better" direction. LEARN just files the verdict away
(learning table) so reporting.weekly_report_md can show "what the system has learned" per action
type - runs / improved / no_change / worse / rejected - the beginnings of a feedback loop for V2+.
"""
from .. import core


def record(conn, account_id, task_id, outcome):
    t = core.row(conn, "SELECT action_type, department FROM tasks WHERE id=?", (task_id,))
    if not t:
        return
    core.execute(conn, "INSERT INTO learning(account_id,action_type,department,outcome,created_at) VALUES(?,?,?,?,?)",
                 (account_id, t["action_type"], t["department"], outcome, core.now()))


def _verdict(before, after, better):
    if before is None or after is None:
        return "unknown"
    delta = (after - before) if better == "higher" else (before - after)
    if abs(delta) < 1e-9:
        return "no_change"
    return "improved" if delta > 0 else "worse"


def measure_due(conn, account, force=False):
    from ..skills import Ctx, metrics  # lazy: skills imports amos.ingest which does not import back, but keep symmetry
    from . import tasks as tasks_engine  # lazy: avoids a tasks.py <-> learning.py import cycle at module load time

    aid = account["id"]
    today = core.today().isoformat()
    sql = "SELECT * FROM tasks WHERE account_id=? AND status='verified'"
    params = [aid]
    if not force:
        sql += " AND measure_due<=?"
        params.append(today)

    ctx = Ctx(conn, account)
    done = []
    for t in core.rows(conn, sql, params):
        baseline = core.loads(t["baseline_json"], None)
        name = before = after = entity = None
        if baseline and baseline.get("name"):
            name, before, entity = baseline.get("name"), baseline.get("value"), baseline.get("entity")
            after = metrics.compute(ctx, name, entity)
            verdict = _verdict(before, after, baseline.get("better", "higher"))
        else:
            verdict = "unknown"

        delta = None if before is None or after is None else round(after - before, 4)
        core.execute(conn, "INSERT INTO measurements(task_id,metric,before_value,after_value,delta,verdict,measured_at) VALUES(?,?,?,?,?,?,?)",
                     (t["id"], name, before, after, delta, verdict, core.now()))
        core.execute(conn, "UPDATE tasks SET status='closed', stage='LEARN', outcome=?, closed_at=?, updated_at=? WHERE id=?",
                     (verdict, core.now(), core.now(), t["id"]))
        tasks_engine.history(conn, t["id"], "MEASURE", "system", f"{name or 'metric'}: {before} -> {after} ({verdict})")
        tasks_engine.history(conn, t["id"], "LEARN", "system", f"Outcome recorded: {verdict}")
        record(conn, aid, t["id"], verdict)
        done.append(t["id"])
    return done


def stats(conn, account_id):
    return core.rows(conn, """SELECT action_type,
        COUNT(*) n,
        SUM(CASE WHEN outcome='improved' THEN 1 ELSE 0 END) improved,
        SUM(CASE WHEN outcome='no_change' THEN 1 ELSE 0 END) no_change,
        SUM(CASE WHEN outcome='worse' THEN 1 ELSE 0 END) worse,
        SUM(CASE WHEN outcome='rejected' THEN 1 ELSE 0 END) rejected
        FROM learning WHERE account_id=? GROUP BY action_type ORDER BY n DESC""", (account_id,))
