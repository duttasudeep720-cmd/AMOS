"""TASK ENGINE. Every task follows the same lifecycle (brief, section 15):

DETECT > ANALYZE > DIAGNOSE > RECOMMEND > APPROVE > EXECUTE > VERIFY > MEASURE > LEARN

The first four stages are performed by the skill that found the issue (recorded in task_history).
`status` is the working state:
  pending_approval (L2) | pending_decision (L3) | human_only (L4) | ready | executed | verified | closed | rejected
"""
import datetime as dt

from .. import core, evidence
from . import policy, priority, learning

STAGES = ["DETECT", "ANALYZE", "DIAGNOSE", "RECOMMEND", "APPROVE", "EXECUTE", "VERIFY", "MEASURE", "LEARN"]
ACTIVE = ("pending_approval", "pending_decision", "human_only", "ready", "executed", "verified")
PRE_EXEC = ("pending_approval", "pending_decision", "human_only", "ready")


def history(conn, task_id, stage, actor, note=""):
    core.execute(conn, "INSERT INTO task_history(task_id,stage,actor,note,at) VALUES(?,?,?,?,?)",
                 (task_id, stage, actor, note, core.now()))


def _due(prio):
    return (core.today() + dt.timedelta(days=priority.DUE_DAYS[prio])).isoformat()


def create_task(conn, account, issue):
    cfg = account["config"]
    rec = core.loads(issue["recommendation_json"], {})
    action = rec.get("action_type", "INVESTIGATE_GENERIC")
    params = rec.get("params", {})
    level, reason = policy.decide(action, params, cfg)
    phase = cfg["phase"]
    if level == 2 and policy.auto_approve(level, action, phase, cfg):
        status, stage = "ready", "EXECUTE"
    elif level <= 1:
        status, stage = "ready", "EXECUTE"
    elif level == 2:
        status, stage = "pending_approval", "APPROVE"
    elif level == 3:
        status, stage = "pending_decision", "APPROVE"
    else:
        status, stage = "human_only", "EXECUTE"
    ts = core.now()
    desc = f"{issue['diagnosis']}\n\nRecommended: {rec.get('summary', '')}"
    tid = core.execute(conn, """INSERT INTO tasks(account_id,issue_id,department,title,description,action_type,action_payload_json,
        priority,score,stage,status,autonomy_level,autonomy_reason,assignee,due_date,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                       (account["id"], issue["id"], issue["department"], issue["title"], desc, action, core.dumps(params),
                        issue["priority"], issue["score"], stage, status, level, reason, issue["department"],
                        _due(issue["priority"]), ts, ts))
    ev = core.loads(issue["evidence_json"], {})
    actor = f"agent:{issue['skill']}"
    history(conn, tid, "DETECT", actor, f"{issue['kind']} detected: {issue['title']}")
    history(conn, tid, "ANALYZE", actor, "Evidence: " + ", ".join(list(ev.keys())[:8]))
    history(conn, tid, "DIAGNOSE", actor, issue["diagnosis"])
    history(conn, tid, "RECOMMEND", actor, f"{action}: {rec.get('summary', '')}")
    history(conn, tid, "APPROVE" if status.startswith("pending") else "EXECUTE", "policy",
            f"Autonomy level {level} - {reason}. Status: {status}")
    core.audit(conn, account["id"], "system", "task_created", "task", tid, {"issue": issue["id"], "level": level})
    return tid


def sync(conn, account):
    """Create tasks for open issues, refresh priorities, close tasks whose issue vanished before action."""
    aid = account["id"]
    created, closed = [], []
    for iss in core.rows(conn, "SELECT * FROM issues WHERE account_id=? AND status='open'", (aid,)):
        t = core.row(conn, f"SELECT id FROM tasks WHERE issue_id=? AND status IN ({','.join('?' * len(ACTIVE))})",
                     (iss["id"],) + ACTIVE)
        if t:
            core.execute(conn, "UPDATE tasks SET priority=?, score=?, title=?, due_date=MIN(due_date,?), updated_at=? "
                               "WHERE id=? AND status IN ('pending_approval','pending_decision','human_only','ready')",
                         (iss["priority"], iss["score"], iss["title"], _due(iss["priority"]), core.now(), t["id"]))
        else:
            created.append(create_task(conn, account, iss))
    for t in core.rows(conn, f"""SELECT t.id FROM tasks t JOIN issues i ON i.id=t.issue_id
            WHERE t.account_id=? AND t.status IN ('pending_approval','pending_decision','human_only','ready') AND i.status='cleared'""", (aid,)):
        core.execute(conn, "UPDATE tasks SET status='closed', stage='LEARN', outcome='resolved_externally', closed_at=?, updated_at=? WHERE id=?",
                     (core.now(), core.now(), t["id"]))
        history(conn, t["id"], "LEARN", "system", "Issue cleared before any action was recorded - closed (resolved externally).")
        learning.record(conn, aid, t["id"], "resolved_externally")
        closed.append(t["id"])
    return {"created": created, "closed": closed}


def _get(conn, task_id):
    t = core.row(conn, "SELECT * FROM tasks WHERE id=?", (task_id,))
    if not t:
        raise KeyError(f"task {task_id} not found")
    return t


def approve(conn, task_id, actor="human", note=""):
    t = _get(conn, task_id)
    if t["status"] not in ("pending_approval", "pending_decision"):
        raise ValueError(f"task {task_id} is '{t['status']}', cannot approve")
    core.execute(conn, "UPDATE tasks SET status='ready', stage='EXECUTE', updated_at=? WHERE id=?", (core.now(), task_id))
    history(conn, task_id, "APPROVE", actor, note or "Approved")
    core.audit(conn, t["account_id"], actor, "task_approved", "task", task_id, {"note": note})
    return _get(conn, task_id)


def reject(conn, task_id, actor="human", note=""):
    t = _get(conn, task_id)
    if t["status"] not in PRE_EXEC:
        raise ValueError(f"task {task_id} is '{t['status']}', cannot reject")
    core.execute(conn, "UPDATE tasks SET status='rejected', outcome='rejected', closed_at=?, updated_at=? WHERE id=?",
                 (core.now(), core.now(), task_id))
    core.execute(conn, "UPDATE issues SET status='ignored' WHERE id=? AND status='open'", (t["issue_id"],))
    history(conn, task_id, "APPROVE", actor, "Rejected: " + (note or "no reason given"))
    learning.record(conn, t["account_id"], task_id, "rejected")
    core.audit(conn, t["account_id"], actor, "task_rejected", "task", task_id, {"note": note})
    return _get(conn, task_id)


def list_tasks(conn, account_id, status=None, department=None, limit=500):
    sql, p = "SELECT * FROM tasks WHERE account_id=?", [account_id]
    if status == "active":
        sql += f" AND status IN ({','.join('?' * len(ACTIVE))})"
        p += list(ACTIVE)
    elif status:
        sql += " AND status=?"
        p.append(status)
    if department:
        sql += " AND department=?"
        p.append(department)
    sql += " ORDER BY priority ASC, score DESC, id ASC LIMIT ?"
    p.append(limit)
    out = core.rows(conn, sql, p)
    for t in out:
        t["action_payload"] = core.loads(t.pop("action_payload_json"), {})
        t["baseline"] = core.loads(t.pop("baseline_json"), None)
    return out


def task_detail(conn, task_id):
    t = _get(conn, task_id)
    t["action_payload"] = core.loads(t.pop("action_payload_json"), {})
    t["baseline"] = core.loads(t.pop("baseline_json"), None)
    t["history"] = core.rows(conn, "SELECT stage,actor,note,at FROM task_history WHERE task_id=? ORDER BY id", (task_id,))
    iss = core.row(conn, "SELECT * FROM issues WHERE id=?", (t["issue_id"],))
    if iss:
        iss["evidence"] = core.loads(iss.pop("evidence_json"), {})
        iss["metric"] = core.loads(iss.pop("metric_json"), None)
        iss["recommendation"] = core.loads(iss.pop("recommendation_json"), {})
        # Structured Evidence layer (amos/evidence.py) - the task never stores its own copy, it
        # just retrieves its issue's evidence rows live (Task -> Issue -> Evidence -> Source data).
        iss["evidence_items"] = evidence.get_issue_evidence(conn, iss["id"])
    t["issue"] = iss
    t["actions"] = core.rows(conn, "SELECT connector,mode,action_type,result_json,created_at FROM actions WHERE task_id=? ORDER BY id", (task_id,))
    t["measurements"] = core.rows(conn, "SELECT * FROM measurements WHERE task_id=?", (task_id,))
    return t
