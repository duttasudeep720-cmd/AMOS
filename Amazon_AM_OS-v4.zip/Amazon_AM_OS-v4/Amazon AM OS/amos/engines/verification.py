"""VERIFICATION ENGINE - the VERIFY stage of the task lifecycle.

A task moves to 'executed' the moment someone (human or agent) acts on it. It only becomes
'verified' once the issue it was raised for has actually CLEARED on a fresh data cycle - not just
because someone clicked a button. "Executed" and "fixed" are different claims; this is where we
check the second one (brief, section 2: "Was it completed? Did it actually improve?").

Three outcomes per executed task, every cycle:
  verified  the issue cleared on fresh data for the skill that owns it       -> stage MEASURE
  failed    fresh data came in, the issue is STILL open, and the grace       -> back to a human
            period (config.verification.measure_days) has elapsed              (pending_decision)
  waiting   no fresh data yet for that skill (or issue/skill unknown)        -> checked again later
"""
import datetime as dt

from .. import core
from . import tasks


def verify_executed(conn, account, ok_skills):
    aid = account["id"]
    grace_days = account["config"]["verification"]["measure_days"]
    verified, failed, waiting = [], [], []

    for t in core.rows(conn, "SELECT * FROM tasks WHERE account_id=? AND status='executed'", (aid,)):
        iss = core.row(conn, "SELECT * FROM issues WHERE id=?", (t["issue_id"],)) if t["issue_id"] else None
        if not iss or iss["skill"] not in ok_skills:
            waiting.append(t["id"])
            continue

        if iss["status"] == "cleared":
            due = (core.today() + dt.timedelta(days=grace_days)).isoformat()
            core.execute(conn, "UPDATE tasks SET status='verified', stage='MEASURE', verified_at=?, measure_due=?, updated_at=? WHERE id=?",
                         (core.now(), due, core.now(), t["id"]))
            tasks.history(conn, t["id"], "VERIFY", "system", "Issue cleared on fresh data - verified.")
            verified.append(t["id"])
            continue

        exec_date = dt.date.fromisoformat((t["executed_at"] or core.now())[:10])
        age = (core.today() - exec_date).days
        if age >= grace_days:
            core.execute(conn, "UPDATE tasks SET status='pending_decision', stage='APPROVE', attempts=attempts+1, updated_at=? WHERE id=?",
                         (core.now(), t["id"]))
            tasks.history(conn, t["id"], "VERIFY", "system",
                          f"Still open {age} day(s) after execution (grace period {grace_days}d) - needs a human look.")
            failed.append(t["id"])
        else:
            waiting.append(t["id"])

    return {"verified": verified, "failed": failed, "waiting": waiting}
