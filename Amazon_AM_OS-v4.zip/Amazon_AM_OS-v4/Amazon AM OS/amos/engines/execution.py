"""EXECUTION ENGINE.

Who performs a task?
  * a human  -> execute_task(..., via="manual")   (default in phase 1-2; the human marks it done)
  * an agent -> execute_task(..., via="agent")    (phase >= 3, only through a Connector, guardrails re-checked)

Connectors are the ONLY code that touches a marketplace. The shipped DryRunConnector records what it
*would* do. To go live, implement a Connector for Amazon SP-API / Amazon Ads API (see HANDOVER.md)
and register it in LIVE_CONNECTORS, then set config execution.mode = "live".
"""
from .. import core
from . import policy, tasks


class Connector:
    name = "base"

    def execute(self, action_type, payload):
        raise NotImplementedError


class DryRunConnector(Connector):
    name = "dry_run"

    def execute(self, action_type, payload):
        return {"mode": "dry_run", "connector": self.name, "action": action_type,
                "would_do": payload, "note": "Nothing was sent to the marketplace."}


class AmazonAdsConnector(Connector):
    """STUB - implement with the Amazon Ads API (bids, negative keywords, budgets)."""
    name = "amazon_ads"

    def execute(self, action_type, payload):
        raise NotImplementedError("Amazon Ads API connector not implemented yet (see HANDOVER.md)")


class AmazonSPAPIConnector(Connector):
    """STUB - implement with SP-API (Listings Items API, Feeds API, Pricing, FBA inbound)."""
    name = "amazon_sp_api"

    def execute(self, action_type, payload):
        raise NotImplementedError("Amazon SP-API connector not implemented yet (see HANDOVER.md)")


LIVE_CONNECTORS = {
    "ADD_NEGATIVE_KEYWORDS": AmazonAdsConnector(), "ADJUST_BID": AmazonAdsConnector(),
    "INCREASE_BUDGET": AmazonAdsConnector(), "ADD_EXACT_KEYWORDS": AmazonAdsConnector(),
    "ADJUST_PRICE": AmazonSPAPIConnector(), "UPDATE_LISTING_CONTENT": AmazonSPAPIConnector(),
    "FIX_CATALOGUE_ATTRIBUTES": AmazonSPAPIConnector(), "ADD_SIZE_CHART": AmazonSPAPIConnector(),
}


def get_connector(cfg, action_type):
    if cfg["execution"]["mode"] == "live":
        c = LIVE_CONNECTORS.get(action_type)
        if not c:
            raise NotImplementedError(f"no live connector for {action_type}")
        return c
    return DryRunConnector()


def execute_task(conn, account, task_id, actor="human", via="manual", note=""):
    cfg = account["config"]
    t = core.row(conn, "SELECT * FROM tasks WHERE id=?", (task_id,))
    if not t:
        raise KeyError(f"task {task_id} not found")
    if t["status"] not in ("ready", "human_only"):
        raise ValueError(f"task {task_id} is '{t['status']}' - approve it first" if t["status"].startswith("pending")
                         else f"task {task_id} is '{t['status']}', cannot execute")
    payload = core.loads(t["action_payload_json"], {})
    issue = core.row(conn, "SELECT metric_json FROM issues WHERE id=?", (t["issue_id"],))

    if via == "agent":
        ok, why = policy.guardrail_check(t["action_type"], payload, cfg)
        if not ok:
            core.execute(conn, "UPDATE tasks SET status='pending_decision', stage='APPROVE', updated_at=? WHERE id=?", (core.now(), task_id))
            tasks.history(conn, task_id, "EXECUTE", "guardrail", f"Agent blocked: {why}. Sent back for a human decision.")
            core.audit(conn, t["account_id"], "guardrail", "agent_blocked", "task", task_id, {"reason": why})
            return {"ok": False, "reason": why}
        try:
            result = get_connector(cfg, t["action_type"]).execute(t["action_type"], payload)
        except Exception as e:  # connector failure never crashes the cycle
            tasks.history(conn, task_id, "EXECUTE", "agent", f"Connector error: {e}")
            core.audit(conn, t["account_id"], "agent", "connector_error", "task", task_id, {"error": str(e)})
            return {"ok": False, "reason": str(e)}
        mode, connector, actor = result.get("mode", "dry_run"), result.get("connector", "dry_run"), "agent"
    else:
        result, mode, connector = {"mode": "manual", "note": note}, "manual", "human"

    ts = core.now()
    core.execute(conn, "INSERT INTO actions(task_id,account_id,connector,action_type,payload_json,result_json,mode,created_at) VALUES(?,?,?,?,?,?,?,?)",
                 (task_id, t["account_id"], connector, t["action_type"], core.dumps(payload), core.dumps(result), mode, ts))
    core.execute(conn, "UPDATE tasks SET status='executed', stage='VERIFY', executed_at=?, baseline_json=?, updated_at=? WHERE id=?",
                 (ts, issue["metric_json"] if issue else None, ts, task_id))
    tasks.history(conn, task_id, "EXECUTE", actor, f"Executed ({mode}). {note}".strip())
    tasks.history(conn, task_id, "VERIFY", "system", "Awaiting fresh data to confirm the issue has cleared.")
    core.audit(conn, t["account_id"], actor, "task_executed", "task", task_id, {"mode": mode, "action": t["action_type"]})
    return {"ok": True, "mode": mode}


def run_agent_queue(conn, account):
    """Let agents execute what policy allows for the current phase. Returns list of executed task ids."""
    cfg = account["config"]
    done = []
    for t in core.rows(conn, "SELECT * FROM tasks WHERE account_id=? AND status='ready'", (account["id"],)):
        if policy.agent_may_execute(t["autonomy_level"], t["action_type"], cfg["phase"], cfg):
            if execute_task(conn, account, t["id"], actor="agent", via="agent").get("ok"):
                done.append(t["id"])
    return done
