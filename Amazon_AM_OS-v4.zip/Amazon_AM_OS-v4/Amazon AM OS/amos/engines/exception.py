"""EXCEPTION ENGINE (brief, section 20: "the system should be exception-driven").

Turns this cycle's raw Findings into durable ISSUES:
  - a finding not seen before        -> new issue, status='open'
  - a finding matching an open issue -> issue refreshed in place (evidence, score, priority)
  - a finding matching a CLEARED     -> issue reopens (it came back)
    issue
  - a finding matching an IGNORED    -> left alone. A human already rejected this; recurring
    issue                               data should not silently override that decision.
  - an open issue whose fingerprint  -> cleared. But ONLY if the skill that would have raised it
    did not reappear this cycle         actually ran (had data) this cycle - a skipped skill
                                         (NoData / error) must never be read as "problem gone".

`fingerprint` = f"{type}:{entity_type}:{entity_id}" (Finding.fingerprint) is what makes an issue
the "same" issue across cycles, however much its evidence/score changes.
"""
from .. import core, evidence
from . import priority


def _issue_columns(f, score_, prio):
    return {
        "title": f.title, "evidence_json": core.dumps(f.evidence), "diagnosis": f.diagnosis,
        "recommendation_json": core.dumps(f.recommendation), "metric_json": core.dumps(f.metric) if f.metric else None,
        "impact": f.impact, "urgency": f.urgency, "confidence": f.confidence, "effort": f.effort,
        "score": score_, "priority": prio,
    }


def process(conn, account, results):
    aid = account["id"]
    now = core.now()
    findings = [f for fs in results.values() if fs for f in fs]

    seen_fp, new, reopened, updated = set(), [], [], []
    for f in findings:
        fp = f.fingerprint
        seen_fp.add(fp)
        s = priority.score(f.impact, f.urgency, f.confidence, f.effort)
        p = priority.bucket(s, f.severity_floor)
        cols = _issue_columns(f, s, p)
        existing = core.row(conn, "SELECT * FROM issues WHERE account_id=? AND fingerprint=?", (aid, fp))

        if not existing:
            iid = core.execute(conn, """INSERT INTO issues(account_id,fingerprint,skill,department,type,kind,entity_type,
                entity_id,title,evidence_json,diagnosis,recommendation_json,metric_json,impact,urgency,confidence,
                effort,score,priority,status,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'open',?,?)""",
                (aid, fp, f.skill, f.department, f.type, f.kind, f.entity_type, f.entity_id, cols["title"],
                 cols["evidence_json"], cols["diagnosis"], cols["recommendation_json"], cols["metric_json"],
                 cols["impact"], cols["urgency"], cols["confidence"], cols["effort"], cols["score"], cols["priority"],
                 now, now))
            new.append(iid)
            evidence.save_issue_evidence(conn, iid, f)
        elif existing["status"] == "open":
            core.execute(conn, """UPDATE issues SET title=?, evidence_json=?, diagnosis=?, recommendation_json=?,
                metric_json=?, impact=?, urgency=?, confidence=?, effort=?, score=?, priority=?, last_seen=? WHERE id=?""",
                (cols["title"], cols["evidence_json"], cols["diagnosis"], cols["recommendation_json"], cols["metric_json"],
                 cols["impact"], cols["urgency"], cols["confidence"], cols["effort"], cols["score"], cols["priority"],
                 now, existing["id"]))
            updated.append(existing["id"])
            evidence.save_issue_evidence(conn, existing["id"], f)
        elif existing["status"] == "cleared":
            core.execute(conn, """UPDATE issues SET status='open', title=?, evidence_json=?, diagnosis=?,
                recommendation_json=?, metric_json=?, impact=?, urgency=?, confidence=?, effort=?, score=?, priority=?,
                last_seen=?, cleared_at=NULL WHERE id=?""",
                (cols["title"], cols["evidence_json"], cols["diagnosis"], cols["recommendation_json"], cols["metric_json"],
                 cols["impact"], cols["urgency"], cols["confidence"], cols["effort"], cols["score"], cols["priority"],
                 now, existing["id"]))
            reopened.append(existing["id"])
            evidence.save_issue_evidence(conn, existing["id"], f)
        # existing["status"] == "ignored": a human rejected this - leave it be, don't reopen.
        # Note: cleared issues are never touched above, so their evidence rows freeze as-is -
        # this is what makes historical evidence survive later changes to the source data
        # (brief section 7: "Historical Evidence != Current Account State").

    # clear: only for issues owned by a skill that actually ran this cycle (result is not None)
    ok_skills = {name for name, v in results.items() if v is not None}
    cleared = []
    for iss in core.rows(conn, "SELECT * FROM issues WHERE account_id=? AND status='open'", (aid,)):
        if iss["skill"] in ok_skills and iss["fingerprint"] not in seen_fp:
            core.execute(conn, "UPDATE issues SET status='cleared', cleared_at=? WHERE id=?", (now, iss["id"]))
            cleared.append(iss["id"])

    return {"new": new, "reopened": reopened, "updated": updated, "cleared": cleared}
