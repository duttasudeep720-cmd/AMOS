"""POLICY ENGINE (brief, section 19: "Human hierarchy should also exist").

Turns a recommended action into an autonomy level, and re-checks hard numeric limits
immediately before an agent (never a human) is allowed to touch a connector.

    Level 0  fully automatic          (reporting/detection only - never reaches this module)
    Level 1  agent executes in-rules  (small, bounded, reversible changes)
    Level 2  agent recommends,        (a single clear proposal - human just approves or rejects it)
             human approves
    Level 3  agent detects,           (no safe default action, or two competing options -
             human decides            the human has to actually decide, not just click yes)
    Level 4  human-only               (account policy / legal / suspension-risk responses)

`phase` (account config) gates how far the system is trusted to act *at all* - see core.py's
DEFAULT_CONFIG docstring on "phase". Even a level-1 action never executes itself before phase 3.
"""

# Base autonomy level per action type. `decide()` may raise this per-case (never lower it) based
# on the actual numbers in `params` - e.g. a 5% bid change is level 1, a 40% one is level 2.
BASE_LEVEL = {
    "ADD_NEGATIVE_KEYWORDS": 1, "ADD_EXACT_KEYWORDS": 1, "ADJUST_BID": 1, "INCREASE_BUDGET": 1,
    "SHIP_ORDERS": 1,
    "ADJUST_PRICE": 2, "UPDATE_LISTING_CONTENT": 2, "FIX_CATALOGUE_ATTRIBUTES": 2, "ADD_SIZE_CHART": 2,
    "FIX_SUPPRESSION": 2, "CREATE_REPLENISHMENT": 2, "RUN_LIQUIDATION_PROMO": 2,
    "INVESTIGATE_BUYBOX": 3, "INVESTIGATE_RETURNS": 3, "INVESTIGATE_SALES_DROP": 3,
    "INVESTIGATE_ACCOUNT_HEALTH": 3, "INVESTIGATE_GENERIC": 3,
    "ACCOUNT_HEALTH_RESPONSE": 4,
}


def decide(action_type, params, cfg):
    """-> (level:int 0-4, reason:str). Called once, when the task is created."""
    params = params or {}
    ads = cfg["ads"]

    if action_type == "ADD_NEGATIVE_KEYWORDS":
        n = len(params.get("terms") or [])
        if n > ads["max_auto_negatives"]:
            return 2, f"{n} negative keyword(s) exceeds the auto limit of {ads['max_auto_negatives']}"
        return 1, f"{n} negative keyword(s), within the auto limit of {ads['max_auto_negatives']}"

    if action_type == "ADJUST_BID":
        chg = abs(params.get("change_pct") or 0)
        if chg > ads["bid_change_limit_pct"]:
            return 2, f"bid change of {chg}% exceeds the auto limit of {ads['bid_change_limit_pct']}%"
        return 1, f"bid change of {chg}% is within the auto limit of {ads['bid_change_limit_pct']}%"

    if action_type == "INCREASE_BUDGET":
        chg = params.get("change_pct") or 0
        if chg > ads["budget_increase_pct"]:
            return 2, f"budget increase of {chg}% exceeds the auto limit of {ads['budget_increase_pct']}%"
        return 1, f"budget increase of {chg}% is within the auto limit of {ads['budget_increase_pct']}%"

    if action_type == "ADJUST_PRICE":
        floor, new_price = params.get("floor"), params.get("new_price")
        if floor and new_price is not None and new_price < floor:
            return 3, "matching this price would breach the minimum viable price - this is a margin-vs-Buy Box trade-off, not a checkbox approval"
        if params.get("compliance_fix"):
            return 2, "price is above MRP (a compliance violation) - human approves the correction before it goes live"
        return 2, "price changes always go to human approval, whatever the size"

    if action_type == "CREATE_REPLENISHMENT":
        return 2, "a replenishment order commits money - human approves the quantity"

    return BASE_LEVEL.get(action_type, 3), f"default policy for {action_type}"


def auto_approve(level, action_type, phase, cfg):
    """Whether a freshly-created level-2 task can skip the approval queue entirely.

    Only true in phase 4 (autonomous within guardrails) AND only for action types the account
    owner has explicitly whitelisted in config.autonomy.l2_auto_actions - an empty list (the
    default) means level-2 tasks always wait for a human, in every phase.
    """
    return level == 2 and phase >= 4 and action_type in (cfg.get("autonomy", {}).get("l2_auto_actions") or [])


def agent_may_execute(autonomy_level, action_type, phase, cfg):
    """Whether an agent (not a human) may execute a task that is already 'ready'.

    phase < 3: never - "monitoring + tasks" and "recommendations" phases are agent-detects-only.
    phase >= 3: level 0-1 actions execute automatically.
    phase >= 4: level-2 actions execute automatically too, but ONLY if whitelisted (see auto_approve).
    Level 3-4 tasks are never agent-executed at any phase - a human already had to decide or act.
    """
    if phase < 3:
        return False
    if autonomy_level <= 1:
        return True
    if autonomy_level == 2:
        return phase >= 4 and action_type in (cfg.get("autonomy", {}).get("l2_auto_actions") or [])
    return False


def guardrail_check(action_type, payload, cfg):
    """Hard numeric limits re-checked immediately before an agent touches a connector.

    This runs even for a task that was already approved - config may have changed since, or the
    approval covered a different number than what's about to be sent. A human executing manually
    (via="manual") is never subject to this: they have already seen the numbers on the task.
    Returns (ok:bool, reason:str). An action type with no guardrail defined here is blocked by
    default (False) - it needs a human until someone writes and reviews the rule for it.
    """
    payload = payload or {}
    ads, pricing = cfg["ads"], cfg["pricing"]

    if action_type == "ADD_NEGATIVE_KEYWORDS":
        terms = payload.get("terms") or []
        if len(terms) > ads["max_auto_negatives"]:
            return False, f"{len(terms)} terms exceeds max_auto_negatives ({ads['max_auto_negatives']})"
        protected = ads.get("protected_terms") or []
        hit = [t for t in terms if any(p and p.lower() in (t or "").lower() for p in protected)]
        if hit:
            return False, f"would negate a protected/brand term: {hit[0]}"
        return True, ""

    if action_type == "ADJUST_BID":
        if abs(payload.get("change_pct") or 0) > ads["bid_change_limit_pct"]:
            return False, f"bid change exceeds bid_change_limit_pct ({ads['bid_change_limit_pct']}%)"
        return True, ""

    if action_type == "INCREASE_BUDGET":
        if (payload.get("change_pct") or 0) > ads["budget_increase_pct"]:
            return False, f"budget change exceeds budget_increase_pct ({ads['budget_increase_pct']}%)"
        return True, ""

    if action_type == "ADD_EXACT_KEYWORDS":
        return True, ""

    if action_type == "SHIP_ORDERS":
        return True, ""

    if action_type == "ADJUST_PRICE":
        floor, new_price, cur = payload.get("floor"), payload.get("new_price"), payload.get("current")
        if floor and new_price is not None and new_price < floor:
            return False, "new price is below the minimum viable price"
        if cur and new_price is not None:
            chg = abs(new_price - cur) / cur * 100
            if chg > pricing["max_auto_price_change_pct"]:
                return False, f"price change of {chg:.1f}% exceeds max_auto_price_change_pct ({pricing['max_auto_price_change_pct']}%)"
        return True, ""

    return False, f"no guardrail rule defined for {action_type} - requires a human"
