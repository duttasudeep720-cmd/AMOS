"""ENGINES package - the execution hierarchy (brief, section 1B).

    exception.py    dedupe findings into issues; clear issues that stopped reproducing
    priority.py     Impact x Urgency x Confidence / Effort -> priority bucket (P1-P4)
    policy.py       autonomy level (0-4) per action + hard guardrails before an agent may act
    tasks.py        the DETECT..LEARN task lifecycle; approve/reject
    execution.py    connectors (dry-run today; SP-API / Ads API stubs for going live)
    verification.py did an executed task's issue actually clear on fresh data?
    learning.py     measure before/after, record outcomes, expose stats for the weekly report

Modules here may import each other directly (they are trusted, not agents), but a module must
never import one that imports it back at module load time - see the lazy imports inside
learning.measure_due() and tasks.create_task() for the two places this would otherwise happen.
"""
