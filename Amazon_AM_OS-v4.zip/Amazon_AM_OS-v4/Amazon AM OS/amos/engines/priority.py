"""PRIORITY ENGINE (brief, section 22: "Impact x Urgency x Confidence x Effort").

We divide by effort rather than multiply (a 1-10 "how much work" scale reads more naturally as a
denominator: more effort for the same impact = lower priority) and drop findings into 4 buckets so
an employee sees "Critical / High / Medium / Monitor", never a raw score (brief, section 20).

A skill can force a floor with `severity_floor` on the Finding (e.g. account suspension risk is
always at least P1 regardless of what the arithmetic says) - `bucket()` never lets the floor make
things LESS urgent, only more.
"""

LABELS = {1: "Critical", 2: "High", 3: "Medium", 4: "Monitor"}
DUE_DAYS = {1: 1, 2: 3, 3: 7, 4: 14}

# score thresholds, tuned against the ranges the shipped skills actually produce (impact/urgency
# 1-10, confidence 0-1, effort 1-10 => raw score up to 100). Revisit once real client data comes in.
THRESHOLDS = ((35, 1), (18, 2), (7, 3))


def score(impact, urgency, confidence, effort):
    impact = impact if impact is not None else 5
    urgency = urgency if urgency is not None else 5
    confidence = confidence if confidence is not None else 0.7
    effort = max(0.5, effort or 1)
    return round((impact * urgency * confidence) / effort, 2)


def bucket(s, severity_floor=None):
    p = next((p for cutoff, p in THRESHOLDS if s >= cutoff), 4)
    if severity_floor:
        p = min(p, severity_floor)
    return p
