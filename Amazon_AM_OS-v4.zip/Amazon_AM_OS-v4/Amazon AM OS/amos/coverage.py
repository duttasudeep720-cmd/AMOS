"""ACCOUNT DATA COVERAGE - what data AMOS actually has for an account, how fresh it is, and which
skills/departments are limited as a result.

This is purely informational (per the brief: missing data is NOT an issue by itself). It never
creates issues or tasks, and never alters the exception/priority/task/policy lifecycle - a skill
that has no data simply raises NoData and is skipped (see director.py), same as before this module
existed. Coverage just makes that visible ahead of time instead of only discovering it mid-cycle.

No new tables. Coverage is derived from two things that already exist:
  - a live COUNT(*)/MAX(date) over each kind's real data table (never guessed/duplicated)
  - the `data_sources` table ingest.touch_source() already maintains, for last_ingested_at

`used_by` / limitations are derived from the `sources` a skill already declares to @skill(...) in
amos/skills/*.py (see skills/base.py) - that list already *is* the "required data" a skill needs,
so nothing new had to be invented there either.
"""
import datetime as dt

from . import core, org
from .ingest import KINDS
from .skills import SKILLS

# kind -> (table, date_column). date_column is None where no single column is a meaningful
# "latest data date" for that table (see ingest.ALIASES) - e.g. `listings` is a live catalogue
# snapshot, not a dated report, so we deliberately do not invent staleness for it from a date.
TABLES = {
    "listings": ("listings", None),
    "inventory": ("inventory", "snapshot_date"),
    "campaigns": ("ad_campaigns", "report_date"),
    "search_terms": ("ad_search_terms", "report_date"),
    "orders": ("orders", "order_date"),
    "returns": ("returns", "return_date"),
    "daily_performance": ("daily_performance", "date"),
    "health_metrics": ("health_metrics", "snapshot_date"),
}

LABELS = {
    "listings": "Listings", "inventory": "Inventory", "campaigns": "Campaigns",
    "search_terms": "Search Terms", "orders": "Orders", "returns": "Returns",
    "daily_performance": "Daily Performance", "health_metrics": "Health Metrics",
}


def _parse_date(s):
    if not s:
        return None
    try:
        return dt.date.fromisoformat(str(s)[:10])
    except ValueError:
        return None


def _kind_coverage(conn, account_id, kind, source_row, freshness_days, today):
    table, date_col = TABLES[kind]
    row_count = core.row(conn, f"SELECT COUNT(*) n FROM {table} WHERE account_id=?", (account_id,))["n"]

    latest_date, age_days = None, None
    if row_count and date_col:
        r = core.row(conn, f"SELECT MAX({date_col}) d FROM {table} WHERE account_id=?", (account_id,))
        latest_date = r["d"] if r else None
        d = _parse_date(latest_date)
        age_days = (today - d).days if d else None

    if row_count == 0:
        status = "missing"
    elif age_days is not None and freshness_days is not None and age_days > freshness_days:
        status = "stale"
    else:
        status = "available"

    return {
        "kind": kind,
        "label": LABELS[kind],
        "status": status,                                    # available | stale | missing
        "row_count": row_count,
        "latest_date": latest_date,                           # None if no date column or no rows
        "age_days": age_days,
        "last_ingested_at": source_row["ingested_at"] if source_row else None,
        "freshness_expectation_days": freshness_days,
        "used_by": sorted(name for name, sd in SKILLS.items() if kind in sd.sources),
    }


def get_account_coverage(conn, account_id):
    """{kind: {...}} for every kind in ingest.KINDS. Always returns all kinds, 'missing' included -
    missing is an expected, normal status here, not an error condition."""
    account = core.get_account(conn, account_id)
    freshness_cfg = account["config"].get("data_freshness", {})
    today = core.today()
    sources = {r["kind"]: r for r in
               core.rows(conn, "SELECT kind, rows, ingested_at FROM data_sources WHERE account_id=?", (account_id,))}
    return {kind: _kind_coverage(conn, account_id, kind, sources.get(kind), freshness_cfg.get(kind), today)
            for kind in KINDS}


def limitations(coverage):
    """One message per affected department, e.g.:
        'Advertising analysis is limited because Search Terms data is not available.'
    Built from the `sources` each skill already declares - never a hardcoded per-skill list, so a
    new skill's own `sources=[...]` is picked up automatically with no change needed here."""
    missing = {k for k, c in coverage.items() if c["status"] == "missing"}
    if not missing:
        return []
    by_dept = {}
    for name, sd in SKILLS.items():
        needed = {k for k in sd.sources if k in missing}
        if not needed:
            continue
        try:
            dept, _agent = org.owner_of(name)
        except (KeyError, StopIteration):
            continue
        entry = by_dept.setdefault(dept.key, {"department": dept.key, "department_name": dept.name,
                                               "labels": set(), "skills": set()})
        entry["labels"] |= needed
        entry["skills"].add(name)
    out = []
    for key in sorted(by_dept):
        e = by_dept[key]
        labels = sorted((LABELS[k] for k in e["labels"]), key=list(LABELS.values()).index)
        need_txt = (labels[0] if len(labels) == 1 else
                    " and ".join(labels) if len(labels) == 2 else
                    ", ".join(labels[:-1]) + f", and {labels[-1]}")
        out.append({
            "department": e["department"],
            "skills": sorted(e["skills"]),
            "message": f"{e['department_name']} analysis is limited because {need_txt} data is not available.",
        })
    return out


def summary_lines(coverage):
    """CLI-friendly lines, one per kind: 'Search Terms      MISSING     0 rows'."""
    lines = []
    for kind in KINDS:
        c = coverage[kind]
        extra = f"{c['row_count']} row{'s' if c['row_count'] != 1 else ''}"
        if c["status"] == "stale" and c["age_days"] is not None:
            extra += f", {c['age_days']}d old (expected within {c['freshness_expectation_days']}d)"
        lines.append(f"{c['label']:<18}{c['status'].upper():<9} {extra}")
    return lines
