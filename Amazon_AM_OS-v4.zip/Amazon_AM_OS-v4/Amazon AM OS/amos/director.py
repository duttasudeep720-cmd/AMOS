"""ACCOUNT DIRECTOR - one per client account. It never edits listings or campaigns itself.

A cycle asks, in order (brief, section 2):
    What is happening? > What is wrong? > Why? > What should be done? > Who does it? > Was it done? > Did it improve?

    departments run their skills            (detect / analyse / diagnose / recommend)
      -> event skills consume cross-department events (agents never call each other)
      -> EXCEPTION engine   (dedupe, clear, ignore)
      -> PRIORITY engine    (Impact x Urgency x Confidence / Effort)
      -> TASK engine        (one task per exception, autonomy level from policy)
      -> VERIFICATION       (did the executed tasks actually fix the issue?)
      -> EXECUTION          (agents act only where phase + policy allow)
      -> MEASURE / LEARN    (results feed back into confidence)
"""
import traceback

from . import core, coverage, org
from .engines import exception, tasks, verification, execution, learning
from .skills import SKILLS, Ctx, NoData


class AccountDirector:
    def __init__(self, conn, account_id):
        self.conn = conn
        self.account = core.get_account(conn, account_id)

    # ---- one department skill ------------------------------------------------------------------
    def _run_skill(self, ctx, name, events, summary):
        sd = SKILLS[name]
        dept, agent = org.owner_of(name)
        ctx.current_skill = name
        try:
            findings = sd.fn(ctx, events) if sd.topics else sd.fn(ctx)
        except NoData as e:
            summary["skipped"][name] = str(e)
            return None
        except Exception as e:  # one broken skill must never stop the cycle
            summary["errors"][name] = f"{type(e).__name__}: {e}"
            core.audit(self.conn, ctx.aid, "system", "skill_error", "skill", name,
                       {"error": str(e), "trace": traceback.format_exc()[-800:]})
            return None
        for f in findings:
            f.skill, f.department = name, dept.key
        summary["skills_run"].append(name)
        return findings

    def run_cycle(self, trigger="manual"):
        self.account = core.get_account(self.conn, self.account["id"])   # pick up config changes
        ctx = Ctx(self.conn, self.account)
        s = {"account_id": ctx.aid, "trigger": trigger, "started": core.now(), "skills_run": [], "skipped": {}, "errors": {}}

        # 0) Data coverage - informational only, computed up front so it reflects what this cycle
        # is about to run against. Never affects exception/priority/task/policy lifecycle below.
        s["data_coverage"] = coverage.get_account_coverage(self.conn, ctx.aid)

        results = {}

        # 1) Departments detect (plain skills first, then event skills fed by this cycle's events)
        for dept in org.ORG:
            for agent in dept.agents:
                for name in agent.skills:
                    if not SKILLS[name].topics:
                        results[name] = self._run_skill(ctx, name, None, s)
        for dept in org.ORG:
            for agent in dept.agents:
                for name in agent.skills:
                    topics = SKILLS[name].topics
                    if topics:
                        # if the publishing skill failed / had no data, we cannot tell 'no events' from 'no signal'
                        if any(results.get(p) is None for p in SKILLS[name].publishers):
                            s["skipped"][name] = "publisher skill did not run"
                            results[name] = None
                            continue
                        evs = [e for e in ctx.events_out if e["topic"] in topics]
                        results[name] = self._run_skill(ctx, name, evs, s)
        s["events"] = len(ctx.events_out)

        # 2-3) Exception + Priority (scores are computed inside the exception engine)
        ex = exception.process(self.conn, self.account, results)
        s.update(new_issues=len(ex["new"]), reopened=len(ex["reopened"]), cleared=len(ex["cleared"]))

        # 4) Tasks
        ts = tasks.sync(self.conn, self.account)
        s.update(tasks_created=len(ts["created"]), tasks_closed_externally=len(ts["closed"]))

        # 5) Verify what humans/agents already executed
        ok_skills = {k for k, v in results.items() if v is not None}
        vr = verification.verify_executed(self.conn, self.account, ok_skills)
        s.update(verified=len(vr["verified"]), verification_failed=len(vr["failed"]), awaiting_data=len(vr["waiting"]))

        # 6) Agents act where policy + phase allow (phase 1-2: never, except level-0 actions)
        s["agent_executed"] = len(execution.run_agent_queue(self.conn, self.account))

        # 7) Measure + learn for anything whose measurement is due
        s["measured"] = len(learning.measure_due(self.conn, self.account))

        s["finished"] = core.now()
        core.audit(self.conn, ctx.aid, "director", "cycle_completed", "account", ctx.aid,
                   {k: v for k, v in s.items() if k not in ("skills_run",)})
        return s

    # ---- human commands routed through the Director ------------------------------------------------
    def approve(self, task_id, actor="human", note=""):
        return tasks.approve(self.conn, task_id, actor, note)

    def reject(self, task_id, actor="human", note=""):
        return tasks.reject(self.conn, task_id, actor, note)

    def execute(self, task_id, actor="human", note="", via="manual"):
        return execution.execute_task(self.conn, self.account, task_id, actor, via, note)

    def measure(self, force=False):
        return learning.measure_due(self.conn, self.account, force)
