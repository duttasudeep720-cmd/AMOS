"""SKILLS package - the reusable Tools layer every agent in amos/org.py is built from (brief,
section 25: "Skill Library").

Each module below registers its functions into base.SKILLS via the @skill(...) decorator the
moment it is imported, so importing this package once (which cli.py / director.py / org.py all do
indirectly by importing `amos`) is enough to populate the registry. Import order does not matter:
cross-skill calls (metrics.py -> catalogue.py / compliance.py, compliance.py/catalogue.py -> ingest.py)
are all done as lazy imports inside functions, never at module load time, so there is no cycle here.

    base.py                Finding/SkillDef/Ctx/NoData + the @skill decorator + shared helpers
    metrics.py              MID = re-measure a finding's metric later, for the Learning engine
    advertising.py          wasted spend, high ACOS, budget-constrained winners, converting terms
    catalogue.py            listing content gaps, size/fit issues from return patterns
    compliance.py           HSN/attribute/category validation rules + the validate_catalogue skill
    health_pricing_cx.py    account health, buy box, price-below-floor, returns, sales anomalies
    inventory_ops.py        stockout risk, overstock, late shipments
"""
from .base import Finding, SkillDef, Ctx, NoData, SKILLS, skill  # noqa: F401
from . import base, metrics, advertising, catalogue, compliance, health_pricing_cx, inventory_ops  # noqa: F401
