"""Advertising department skills. ACOS = spend / ad sales. All spend/sales figures come from the last report."""
from collections import defaultdict

from .base import Finding, skill, clamp, inr, pct, safe_div


def _is_protected(term, protected):
    t = (term or "").lower()
    return any(p.lower() in t for p in protected if p)


def wasted_terms_by_campaign(ctx):
    """{campaign: [search-term rows with enough clicks/spend and zero orders]} (protected brand terms excluded)."""
    cfg = ctx.cfg["ads"]
    out = defaultdict(list)
    for t in ctx.require("ad_search_terms"):
        if (t["orders"] or 0) == 0 and (t["clicks"] or 0) >= cfg["wasted_min_clicks"] \
                and (t["spend"] or 0) >= cfg["wasted_min_spend"] and not _is_protected(t["search_term"], cfg["protected_terms"]):
            out[t["campaign"]].append(t)
    return out


@skill("detect_wasted_ad_spend", sources=["search_terms"],
       description="Find search terms with many clicks and zero orders; propose negative keywords.")
def detect_wasted_ad_spend(ctx):
    cfg = ctx.cfg["ads"]
    camp_spend = {c["campaign"]: c["spend"] for c in ctx.all("ad_campaigns")}
    out = []
    for camp, ts in wasted_terms_by_campaign(ctx).items():
        ts.sort(key=lambda t: -t["spend"])
        total = sum(t["spend"] for t in ts)
        share = safe_div(total, camp_spend.get(camp), 0) or 0
        out.append(Finding(
            type="wasted_ad_spend", entity_type="campaign", entity_id=camp,
            title=f"{camp}: {inr(total)} spent on {len(ts)} search term(s) with zero orders",
            diagnosis=(f"{len(ts)} search terms each have >= {cfg['wasted_min_clicks']} clicks and 0 orders, "
                       f"burning {inr(total)} ({pct(share, 0)} of campaign spend)."),
            recommendation={"action_type": "ADD_NEGATIVE_KEYWORDS",
                            "summary": f"Add {len(ts)} negative exact keywords to {camp}.",
                            "params": {"campaign": camp, "match_type": "negative_exact",
                                       "terms": [t["search_term"] for t in ts]}},
            evidence={"total_wasted": total, "share_of_campaign_spend": share,
                      "top_terms": [{"term": t["search_term"], "clicks": t["clicks"], "spend": t["spend"]} for t in ts[:15]]},
            impact=clamp(2 + total / 600), urgency=6, confidence=0.9, effort=1.5,
            metric={"name": "campaign_wasted_spend", "value": total, "better": "lower", "entity": camp}))
    return out


@skill("detect_high_acos_campaigns", sources=["campaigns", "search_terms"],
       description="Campaigns whose ACOS is well above target after removing wasted spend.")
def detect_high_acos_campaigns(ctx):
    cfg, tgt = ctx.cfg["ads"], ctx.cfg["targets"]["acos"]
    camps = ctx.require("ad_campaigns")
    try:
        waste = {c: sum(t["spend"] for t in ts) for c, ts in wasted_terms_by_campaign(ctx).items()}
    except Exception:
        waste = {}
    out = []
    for c in camps:
        spend, sales = c["spend"] or 0, c["sales"] or 0
        if spend < cfg["min_campaign_spend"]:
            continue
        acos = safe_div(spend, sales)
        if acos is not None and acos <= tgt * cfg["high_acos_factor"]:
            continue
        w = waste.get(c["campaign"], 0)
        residual = safe_div(spend - w, sales)
        if residual is not None and residual <= tgt * cfg["high_acos_factor"]:
            continue   # root cause is wasted spend - already covered by the negative-keyword task
        ratio = (acos / tgt) if acos else 5
        change = -10 if ratio < 2 else -20
        acos_txt = "no sales" if acos is None else pct(acos)
        out.append(Finding(
            type="high_acos_campaign", entity_type="campaign", entity_id=c["campaign"],
            title=f"{c['campaign']}: ACOS {acos_txt} vs target {pct(tgt, 0)} ({inr(spend)} spend)",
            diagnosis=(f"ACOS {acos_txt}; wasted search terms explain only {inr(w)} of {inr(spend)}. "
                       f"Residual ACOS {pct(residual) if residual else 'n/a'} -> bids too high for current conversion."),
            recommendation={"action_type": "ADJUST_BID", "summary": f"Reduce bids by {abs(change)}% and re-check in 7 days.",
                            "params": {"campaign": c["campaign"], "change_pct": change}},
            evidence={"spend": spend, "sales": sales, "acos": acos, "wasted": w, "residual_acos": residual},
            impact=clamp(3 + spend / 1500), urgency=6, confidence=0.75, effort=2,
            metric={"name": "campaign_acos", "value": acos if acos is not None else 9.99, "better": "lower", "entity": c["campaign"]}))
    return out


@skill("find_budget_constrained_winners", sources=["campaigns"],
       description="Efficient campaigns that exhaust their daily budget (opportunity).")
def find_budget_constrained_winners(ctx):
    cfg, tgt = ctx.cfg["ads"], ctx.cfg["targets"]["acos"]
    out = []
    for c in ctx.require("ad_campaigns"):
        if not c["daily_budget"] or (c["orders"] or 0) < 5:
            continue
        util = safe_div(c["spend"], c["daily_budget"] * (c["days"] or 7), 0)
        acos = safe_div(c["spend"], c["sales"])
        if util >= cfg["budget_util_threshold"] and acos is not None and acos <= tgt * 0.9:
            out.append(Finding(
                type="budget_constrained_winner", entity_type="campaign", entity_id=c["campaign"], kind="opportunity",
                title=f"{c['campaign']}: profitable (ACOS {pct(acos)}) but budget {pct(util, 0)} used",
                diagnosis="Campaign converts below target ACOS and runs out of budget - sales are being left on the table.",
                recommendation={"action_type": "INCREASE_BUDGET",
                                "summary": f"Raise daily budget by {cfg['budget_increase_pct']}%.",
                                "params": {"campaign": c["campaign"], "current": c["daily_budget"],
                                           "change_pct": cfg["budget_increase_pct"]}},
                evidence={"acos": acos, "budget_utilisation": util, "orders": c["orders"]},
                impact=clamp(3 + c["sales"] / 6000), urgency=4, confidence=0.7, effort=1.5,
                metric={"name": "campaign_sales", "value": c["sales"], "better": "higher", "entity": c["campaign"]}))
    return out


@skill("harvest_converting_terms", sources=["search_terms"],
       description="Converting broad/phrase/auto search terms not yet targeted as exact keywords (opportunity).")
def harvest_converting_terms(ctx):
    cfg, tgt = ctx.cfg["ads"], ctx.cfg["targets"]["acos"]
    by = defaultdict(list)
    for t in ctx.require("ad_search_terms"):
        acos = safe_div(t["spend"], t["sales"])
        if (t["orders"] or 0) >= cfg["harvest_min_orders"] and acos is not None and acos <= tgt \
                and (t["match_type"] or "").lower() != "exact":
            by[t["campaign"]].append(t)
    out = []
    for camp, ts in by.items():
        ts.sort(key=lambda t: -t["sales"])
        sales = sum(t["sales"] for t in ts)
        out.append(Finding(
            type="keyword_harvest", entity_type="campaign", entity_id=camp, kind="opportunity",
            title=f"{camp}: {len(ts)} converting search term(s) to harvest as exact keywords",
            diagnosis=f"{len(ts)} terms convert under target ACOS ({inr(sales)} sales) but are not targeted as exact match.",
            recommendation={"action_type": "ADD_EXACT_KEYWORDS", "summary": "Add as exact-match keywords in a dedicated campaign.",
                            "params": {"source_campaign": camp, "terms": [t["search_term"] for t in ts]}},
            evidence={"terms": [{"term": t["search_term"], "orders": t["orders"], "sales": t["sales"]} for t in ts[:15]]},
            impact=clamp(2.5 + sales / 5000), urgency=3, confidence=0.75, effort=2.5))
    return out
