"""Catalogue & Content department skills."""
from .base import Finding, skill, clamp, units_share, hero_skus, pct


def listing_gaps(l, cfg, is_hero):
    """Each gap carries actual/expected/operator alongside its human `issue` text, so the Evidence
    layer (amos/evidence.py) can show structured facts instead of just parsing the sentence."""
    c = cfg["catalogue"]
    gaps = []
    tl = len(l["title"] or "")
    if tl < c["title_min"]:
        gaps.append({"field": "title", "issue": f"Title is {tl} chars (target {c['title_min']}-{c['title_max']})",
                     "actual": tl, "expected": c["title_min"], "operator": "<"})
    elif tl > c["title_max"]:
        gaps.append({"field": "title", "issue": f"Title is {tl} chars (max {c['title_max']})",
                     "actual": tl, "expected": c["title_max"], "operator": ">"})
    if (l["bullet_count"] or 0) < c["bullets_min"]:
        gaps.append({"field": "bullets", "issue": f"{l['bullet_count'] or 0} bullets (target {c['bullets_min']})",
                     "actual": l["bullet_count"] or 0, "expected": c["bullets_min"], "operator": "<"})
    if (l["image_count"] or 0) < c["images_min"]:
        gaps.append({"field": "images", "issue": f"{l['image_count'] or 0} images (target {c['images_min']})",
                     "actual": l["image_count"] or 0, "expected": c["images_min"], "operator": "<"})
    if (l["description_len"] or 0) < c["description_min"]:
        gaps.append({"field": "description", "issue": f"Description {l['description_len'] or 0} chars (target {c['description_min']})",
                     "actual": l["description_len"] or 0, "expected": c["description_min"], "operator": "<"})
    if c["aplus_for_hero"] and is_hero and not l["has_aplus"]:
        gaps.append({"field": "a_plus", "issue": "Hero SKU has no A+ content",
                     "actual": False, "expected": True, "operator": "=="})
    return gaps


@skill("audit_listing_content", sources=["listings"],
       description="Audit title/bullets/images/description/A+ and link gaps to conversion.")
def audit_listing_content(ctx):
    ls = ctx.require("listings", "status='active'")
    hero = hero_skus(ctx)
    cfg = ctx.cfg
    out = []
    for l in ls:
        gaps = listing_gaps(l, cfg, l["sku"] in hero)
        if not gaps:
            continue
        low_conv = ((l["sessions"] or 0) >= cfg["catalogue"]["min_sessions_for_conv"]
                    and l["conversion_pct"] is not None and l["conversion_pct"] < cfg["targets"]["min_conversion"])
        share = units_share(ctx, l["units_30d"])
        if low_conv:
            diagnosis = (f"Traffic is healthy ({l['sessions']} sessions) but conversion is {pct(l['conversion_pct'])} "
                         f"(target {pct(cfg['targets']['min_conversion'])}) -> listing/content problem. "
                         f"Gaps: {'; '.join(g['issue'] for g in gaps[:4])}")
            metric = {"name": "listing_conversion", "value": l["conversion_pct"], "better": "higher", "entity": l["sku"]}
        else:
            diagnosis = "Content below standard: " + "; ".join(g["issue"] for g in gaps[:4])
            metric = {"name": "listing_gaps", "value": len(gaps), "better": "lower", "entity": l["sku"]}
        out.append(Finding(
            type="listing_content_gaps", entity_type="sku", entity_id=l["sku"],
            title=f"{l['sku']}: {len(gaps)} listing content gap(s)" + (" - low conversion" if low_conv else ""),
            diagnosis=diagnosis,
            recommendation={"action_type": "UPDATE_LISTING_CONTENT",
                            "summary": "Rewrite/complete: " + ", ".join(g["field"] for g in gaps),
                            "params": {"sku": l["sku"], "fields": [g["field"] for g in gaps]}},
            evidence={"gaps": gaps, "sessions": l["sessions"], "conversion": l["conversion_pct"],
                      "units_30d": l["units_30d"], "is_hero": l["sku"] in hero},
            impact=clamp(2.5 + share * 40 + (2.5 if low_conv else 0) + len(gaps) * 0.4),
            urgency=7 if low_conv else 4, confidence=0.85 if low_conv else 0.7,
            effort=clamp(1.5 + len(gaps)), metric=metric))
    return out


@skill("size_chart_from_returns", sources=["listings", "returns"], topics=["returns.pattern"],
       publishers=["analyze_returns"],
       description="Event skill: when CX finds a size-related return pattern, verify the size chart on the listing.")
def size_chart_from_returns(ctx, events):
    """This is the CX -> Catalogue hand-off from the brief (section 10): return reason 'size smaller than
    expected' -> repeated pattern -> catalogue checks the size chart -> correction task."""
    from ..ingest import parse_attrs
    out = []
    listings = {l["sku"]: l for l in ctx.all("listings")}
    for ev in events:
        p = ev["payload"]
        if p.get("pattern") != "size":
            continue
        l = listings.get(p["sku"])
        if not l:
            continue
        has_chart = str(parse_attrs(l).get("size_chart", "")).strip().lower() in ("yes", "y", "true", "1")
        share = units_share(ctx, l["units_30d"])
        ev_ = {"return_rate": p["return_rate"], "size_share_of_returns": p["share"], "returned_units": p["returned_units"]}
        if not has_chart:
            out.append(Finding(
                type="size_chart_missing", entity_type="sku", entity_id=l["sku"],
                title=f"{l['sku']}: size-related returns and NO size chart on listing",
                diagnosis=(f"{pct(p['share'], 0)} of returns cite size/fit ({p['returned_units']} units, return rate "
                           f"{pct(p['return_rate'])}) and the listing has no size chart -> add an accurate size chart."),
                recommendation={"action_type": "ADD_SIZE_CHART", "summary": "Add a measured size chart (image + table).",
                                "params": {"sku": l["sku"]}},
                evidence=ev_, impact=clamp(5 + share * 35), urgency=6, confidence=0.85, effort=3,
                metric={"name": "return_rate", "value": p["return_rate"], "better": "lower", "entity": l["sku"]}))
        else:
            out.append(Finding(
                type="size_chart_check", entity_type="sku", entity_id=l["sku"],
                title=f"{l['sku']}: size returns despite size chart - verify chart accuracy",
                diagnosis=(f"{pct(p['share'], 0)} of returns cite size/fit although a chart exists -> chart may be "
                           f"inaccurate or the fit runs small/large; re-measure and add a fit note."),
                recommendation={"action_type": "UPDATE_LISTING_CONTENT", "summary": "Re-measure garment; correct chart; add fit note.",
                                "params": {"sku": l["sku"], "fields": ["size_chart"]}},
                evidence=ev_, impact=clamp(4 + share * 30), urgency=5, confidence=0.7, effort=3,
                metric={"name": "return_rate", "value": p["return_rate"], "better": "lower", "entity": l["sku"]}))
    return out
