"""Account Health, Pricing, Returns & CX, and Analytics department skills."""
import re
from collections import Counter, defaultdict

from .base import Finding, skill, clamp, inr, pct, units_share, hero_skus, min_viable_price, safe_div


# ------------------------------------ ACCOUNT HEALTH -------------------------------------------
@skill("detect_suppressed_listings", sources=["listings"],
       description="Listings that are suppressed / inactive with the reason Amazon gave.")
def detect_suppressed_listings(ctx):
    out = []
    for l in ctx.require("listings", "status != 'active'"):
        share = units_share(ctx, l["units_30d"])
        out.append(Finding(
            type="listing_suppressed", entity_type="sku", entity_id=l["sku"],
            title=f"{l['sku']} is {l['status']}: {l['status_reason'] or 'reason not provided'}",
            diagnosis=f"Listing not buyable. Reason: {l['status_reason'] or 'unknown'}. Lost sales until fixed "
                      f"(SKU normally {l['units_30d'] or 0} units/30d).",
            recommendation={"action_type": "FIX_SUPPRESSION", "summary": "Open Fix Your Products, resolve the reason, resubmit.",
                            "params": {"sku": l["sku"], "reason": l["status_reason"]}},
            evidence={"status": l["status"], "reason": l["status_reason"], "units_30d": l["units_30d"], "asin": l["asin"]},
            impact=clamp(4 + share * 45), urgency=9, confidence=0.98, effort=3,
            severity_floor=1 if share >= 0.05 else 2,
            metric={"name": "listing_active", "value": 0, "better": "higher", "entity": l["sku"]}))
    return out


@skill("check_buy_box", sources=["listings"],
       description="Buy Box share drops; diagnose price vs stock vs other, respecting the minimum viable price.")
def check_buy_box(ctx):
    cfg = ctx.cfg["buybox"]
    inv = {i["sku"]: i for i in ctx.all("inventory")}
    out = []
    for l in ctx.require("listings", "status='active'"):
        cur, prev = l["buy_box_pct"], l["buy_box_pct_prev"]
        if cur is None or (l["units_30d"] or 0) == 0:
            continue
        dropped = prev is not None and (prev - cur) >= cfg["drop_pts"]
        if not (dropped or cur < cfg["min_pct"]):
            continue
        floor_price = min_viable_price(l, ctx.cfg)
        causes, action, params, level_note = [], "INVESTIGATE_BUYBOX", {"sku": l["sku"]}, ""
        stock = inv.get(l["sku"])
        if stock and stock["avg_daily_sales"] and stock["stock"] / stock["avg_daily_sales"] < 3:
            causes.append("stock nearly out (Buy Box suppressed when inventory is very low)")
        if l["buybox_price"] and l["price"] and l["price"] > l["buybox_price"] * 1.02:
            causes.append(f"our price {inr(l['price'])} is above Buy Box price {inr(l['buybox_price'])}")
            target = l["buybox_price"]
            if floor_price and target < floor_price:
                level_note = (f" Matching {inr(target)} would breach the minimum viable price {inr(floor_price)} - "
                              f"do NOT match blindly; decide whether to accept the margin hit or hold price.")
            else:
                action = "ADJUST_PRICE"
                params = {"sku": l["sku"], "current": l["price"], "new_price": target, "floor": floor_price}
        if not causes:
            causes.append("cause not visible in data: check fulfilment method, competitor offers, listing changes")
        pretty = f"{pct(prev, 0)} -> {pct(cur, 0)}" if prev is not None else pct(cur, 0)
        share = units_share(ctx, l["units_30d"])
        out.append(Finding(
            type="buy_box_lost", entity_type="sku", entity_id=l["sku"],
            title=f"{l['sku']}: Buy Box {pretty}",
            diagnosis="Likely cause(s): " + "; ".join(causes) + "." + level_note,
            recommendation={"action_type": action, "summary": (
                f"Set price to {inr(params.get('new_price'))} (floor {inr(floor_price)})." if action == "ADJUST_PRICE"
                else "Investigate Buy Box loss (price, fulfilment, competitors, stock)." + level_note), "params": params},
            evidence={"buy_box_pct": cur, "buy_box_pct_prev": prev, "price": l["price"], "buybox_price": l["buybox_price"],
                      "min_viable_price": floor_price, "causes": causes},
            impact=clamp(4 + share * 40), urgency=8, confidence=0.75, effort=2.5,
            severity_floor=2 if share >= 0.05 else None,
            metric={"name": "buy_box_pct", "value": cur, "better": "higher", "entity": l["sku"]}))
    return out


@skill("check_account_health_metrics", sources=["health_metrics"],
       description="Amazon account health metrics vs their limits (ODR, late dispatch, cancellations...).")
def check_account_health_metrics(ctx):
    out = []
    for m in ctx.require("health_metrics"):
        v, lim = m["value"], m["limit_value"]
        if v is None or lim is None:
            continue
        mx = (m["direction"] or "max") == "max"
        breached = v > lim if mx else v < lim
        # max-type metrics: share of the allowed limit already used; min-type: how close we are to the floor
        used = (v / lim) if mx else (lim / v if v else 9)
        at_risk = used >= 0.8 if mx else v <= lim * 1.03
        if not breached and not at_risk:
            continue
        out.append(Finding(
            type="health_metric", entity_type="account", entity_id=m["metric"],
            title=f"Account health: {m['metric']} {v * 100:.2f}% vs limit {lim * 100:.2f}%" + (" - BREACHED" if breached else " - at risk"),
            diagnosis=("Metric outside Amazon's target: suspension risk." if breached else
                       f"Metric is close to its limit ({v * 100:.2f}% vs {lim * 100:.2f}%); act before it breaches."),
            recommendation={"action_type": "ACCOUNT_HEALTH_RESPONSE" if breached else "INVESTIGATE_ACCOUNT_HEALTH",
                            "summary": "Human review of root causes and, if needed, a plan of action.", "params": {"metric": m["metric"]}},
            evidence={"value": v, "limit": lim, "limit_used": round(used, 2)},
            impact=10 if breached else 7, urgency=10 if breached else 6, confidence=0.95, effort=5,
            severity_floor=1 if breached else 2,
            metric={"name": "health_metric", "value": v, "better": "lower" if mx else "higher", "entity": m["metric"]}))
    return out


# ------------------------------------ PRICING ----------------------------------------------------
@skill("detect_price_below_floor", sources=["listings"],
       description="Selling price below cost + fees + shipping + ads + target margin (margin leak) and MRP sanity.")
def detect_price_below_floor(ctx):
    cfgp = ctx.cfg["pricing"]
    out = []
    for l in ctx.require("listings", "status='active'"):
        floor = min_viable_price(l, ctx.cfg)
        share = units_share(ctx, l["units_30d"])
        if floor and l["price"] and l["price"] < floor:
            change = (floor - l["price"]) / l["price"] * 100
            out.append(Finding(
                type="price_below_floor", entity_type="sku", entity_id=l["sku"],
                title=f"{l['sku']}: price {inr(l['price'])} is below minimum viable {inr(floor)}",
                diagnosis=(f"Cost {inr(l['cost'])} + shipping + {pct(l['fee_pct'] if l['fee_pct'] is not None else cfgp['default_fee_pct'], 0)} fees "
                           f"+ {pct(ctx.cfg['targets']['tacos'], 0)} ads + {pct(ctx.cfg['targets']['target_margin'], 0)} margin => {inr(floor)}. "
                           f"Each unit currently sells below target margin."),
                recommendation={"action_type": "ADJUST_PRICE", "summary": f"Raise price to {inr(floor)} (+{change:.1f}%) or cut cost.",
                                "params": {"sku": l["sku"], "current": l["price"], "new_price": floor, "floor": floor, "change_pct": round(change, 1)}},
                evidence={"price": l["price"], "min_viable_price": floor, "cost": l["cost"], "change_pct": round(change, 1)},
                impact=clamp(3 + share * 40 + change / 5), urgency=6, confidence=0.85, effort=2,
                metric={"name": "price_vs_floor", "value": l["price"] / floor, "better": "higher", "entity": l["sku"]}))
        if l["price"] and l["mrp"] and l["price"] > l["mrp"]:
            out.append(Finding(
                type="price_above_mrp", entity_type="sku", entity_id=l["sku"],
                title=f"{l['sku']}: price {inr(l['price'])} exceeds MRP {inr(l['mrp'])}",
                diagnosis="Selling above MRP is a compliance violation in India.",
                recommendation={"action_type": "ADJUST_PRICE", "summary": "Set price at or below MRP (or correct MRP).",
                                "params": {"sku": l["sku"], "current": l["price"], "new_price": l["mrp"], "floor": floor,
                                            "compliance_fix": True}},
                evidence={"price": l["price"], "mrp": l["mrp"]}, impact=8, urgency=9, confidence=0.98, effort=1,
                severity_floor=2, metric={"name": "price_vs_mrp", "value": l["price"] / l["mrp"], "better": "lower", "entity": l["sku"]}))
    return out


# ------------------------------------ RETURNS & CX -----------------------------------------------
REASON_PATTERNS = [
    ("size", r"size|fit|small|large|tight|loose|length"),
    ("defect", r"defect|damage|torn|broken|stitch|faulty|stain"),
    ("description", r"not as described|different|colou?r|photo|picture|image|fabric|quality"),
    ("logistics", r"late|delay|wrong item|missing"),
]


def categorise_reason(text):
    t = (text or "").lower()
    for cat, pat in REASON_PATTERNS:
        if re.search(pat, t):
            return cat
    return "other"


@skill("analyze_returns", sources=["returns", "listings"],
       description="Return rate per SKU and reason pattern; publishes 'returns.pattern' events for other departments.")
def analyze_returns(ctx):
    cfg = ctx.cfg["returns"]
    units = {l["sku"]: l["units_30d"] or 0 for l in ctx.all("listings")}
    by = defaultdict(list)
    for r in ctx.require("returns"):
        by[r["sku"]].append(r)
    out = []
    for sku, rs in by.items():
        qty = sum(r["qty"] or 1 for r in rs)
        u = units.get(sku, 0)
        rate = safe_div(qty, u)
        if rate is None or qty < cfg["min_returned_units"]:
            continue
        if rate < cfg["return_rate_threshold"]:
            continue
        cats = Counter()
        for r in rs:
            cats[categorise_reason(r["reason"])] += r["qty"] or 1
        top, top_n = cats.most_common(1)[0]
        share = top_n / qty
        if top in ("size", "description") and share >= cfg["pattern_share"]:
            ctx.publish("returns.pattern", {"sku": sku, "pattern": top, "share": round(share, 2),
                                            "return_rate": round(rate, 3), "returned_units": qty})
        s = units_share(ctx, u)
        out.append(Finding(
            type="high_return_rate", entity_type="sku", entity_id=sku,
            title=f"{sku}: return rate {pct(rate)} ({qty} of {u} units), top reason: {top}",
            diagnosis=f"Return rate above {pct(cfg['return_rate_threshold'], 0)}; {pct(share, 0)} of returns are '{top}'. "
                      f"Reasons: {dict(cats)}. Pattern shared with Catalogue for a content/size-chart check.",
            recommendation={"action_type": "INVESTIGATE_RETURNS", "summary": f"Review '{top}' returns; fix at source (catalogue, QC, packaging).",
                            "params": {"sku": sku, "top_reason": top}},
            evidence={"return_rate": rate, "returned_units": qty, "reasons": dict(cats)},
            impact=clamp(3 + s * 35 + rate * 10), urgency=5, confidence=0.8, effort=3,
            metric={"name": "return_rate", "value": rate, "better": "lower", "entity": sku}))
    return out


# ------------------------------------ ANALYTICS --------------------------------------------------
@skill("detect_sales_anomaly", sources=["daily_performance"],
       description="Latest day's sales vs trailing 7-day average; splits traffic vs conversion.")
def detect_sales_anomaly(ctx):
    days = sorted(ctx.require("daily_performance"), key=lambda d: d["date"])
    if len(days) < 8:
        return []
    last, prev = days[-1], days[-8:-1]
    avg = sum(d["sales"] for d in prev) / 7
    if avg <= 0:
        return []
    drop = (avg - last["sales"]) / avg
    if drop < ctx.cfg["analytics"]["sales_drop_pct"]:
        return []
    avg_sess = sum(d["sessions"] for d in prev) / 7 or 1
    avg_conv = safe_div(sum(d["orders"] for d in prev), sum(d["sessions"] for d in prev), 0)
    sess_chg = (last["sessions"] - avg_sess) / avg_sess
    conv = safe_div(last["orders"], last["sessions"], 0)
    conv_chg = (conv - avg_conv) / avg_conv if avg_conv else 0
    cause = ("traffic fell" if sess_chg < -0.15 and conv_chg > -0.15 else
             "conversion fell" if conv_chg < -0.15 and sess_chg > -0.15 else "both traffic and conversion fell")
    return [Finding(
        type="sales_drop", entity_type="account", entity_id="sales",
        title=f"Sales on {last['date']} down {drop * 100:.0f}% vs 7-day average ({inr(last['sales'])} vs {inr(avg)})",
        diagnosis=f"{cause.capitalize()}: sessions {sess_chg * 100:+.0f}%, conversion {conv_chg * 100:+.0f}% vs trailing week.",
        recommendation={"action_type": "INVESTIGATE_SALES_DROP",
                        "summary": "Check suppressions, Buy Box, stock, ad budget exhaustion and competitor promos for that day.",
                        "params": {"date": last["date"], "cause": cause}},
        evidence={"date": last["date"], "sales": last["sales"], "avg_7d": avg, "sessions_change": sess_chg, "conversion_change": conv_chg},
        impact=clamp(4 + drop * 10), urgency=8, confidence=0.7, effort=4,
        metric={"name": "daily_sales", "value": last["sales"], "better": "higher", "entity": "sales"})]
