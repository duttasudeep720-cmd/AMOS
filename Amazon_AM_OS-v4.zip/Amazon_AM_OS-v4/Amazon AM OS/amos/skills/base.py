"""Skill framework.

A SKILL is a pure, reusable function:  fn(ctx) -> list[Finding]
Agents are just named bundles of skills (see amos/org.py). Skills never write tasks and never
call other agents; they only return findings (and may publish events on the bus).

Event skills (topics=[...]) receive the events published by other skills in the same cycle:
    fn(ctx, events) -> list[Finding]
"""
import math
from dataclasses import dataclass, field
from typing import Callable, Optional

from .. import core


class NoData(Exception):
    """Raised by a skill when its source data has not been ingested (skill is skipped, nothing is cleared)."""


@dataclass
class Finding:
    type: str                      # e.g. "wasted_ad_spend" (stable, used in the fingerprint)
    entity_type: str               # sku | campaign | account | order_batch ...
    entity_id: str
    title: str
    diagnosis: str = ""
    recommendation: dict = field(default_factory=dict)   # {action_type, summary, params}
    evidence: dict = field(default_factory=dict)
    kind: str = "issue"            # issue | opportunity
    impact: float = 5               # 1-10  business impact if left alone / value if captured
    urgency: float = 5              # 1-10
    confidence: float = 0.8         # 0-1
    effort: float = 3               # 1-10 (higher = more work)
    severity_floor: Optional[int] = None   # force minimum priority (1 = P1)
    metric: Optional[dict] = None  # {"name","value","better": "lower|higher", "entity": id}
    skill: str = ""                # filled by the runner
    department: str = ""           # filled by the runner from org.py

    @property
    def fingerprint(self):
        return f"{self.type}:{self.entity_type}:{self.entity_id}"


@dataclass
class SkillDef:
    name: str
    fn: Callable
    sources: tuple = ()
    topics: tuple = ()
    publishers: tuple = ()      # skills that publish the topics this skill consumes
    description: str = ""


SKILLS = {}


def skill(name, sources=(), topics=(), publishers=(), description=""):
    def deco(fn):
        SKILLS[name] = SkillDef(name, fn, tuple(sources), tuple(topics), tuple(publishers),
                                description or (fn.__doc__ or "").strip())
        return fn
    return deco


class Ctx:
    """Everything a skill may touch: the account's data (read-only by convention), config and event bus."""

    def __init__(self, conn, account):
        self.conn = conn
        self.account = account
        self.aid = account["id"]
        self.cfg = account["config"]
        self.today = core.today()
        self.cache = {}
        self.events_out = []
        self.current_skill = None

    def all(self, table, where="1=1", params=()):
        return core.rows(self.conn, f"SELECT * FROM {table} WHERE account_id=? AND ({where})", (self.aid,) + tuple(params))

    def require(self, table, where="1=1", params=()):
        r = self.all(table, where, params)
        if not r and not self.all(table):
            raise NoData(f"no data in {table}")
        return r

    def publish(self, topic, payload):
        self.events_out.append({"topic": topic, "payload": payload, "source": self.current_skill})
        core.execute(self.conn, "INSERT INTO events(account_id,topic,payload_json,source,created_at) VALUES(?,?,?,?,?)",
                     (self.aid, topic, core.dumps(payload), self.current_skill, core.now()))


# ------------------------------- shared helpers ----------------------------------------------
def clamp(x, lo=1.0, hi=10.0):
    return max(lo, min(hi, x))


def safe_div(a, b, default=None):
    try:
        return a / b if b else default
    except TypeError:
        return default


def inr(x):
    if x is None:
        return "-"
    return f"₹{x:,.0f}"


def pct(x, nd=1):
    return "-" if x is None else f"{x * 100:.{nd}f}%"


def hero_skus(ctx):
    """SKUs that together make up `hero_share` of 30-day units. Cached per cycle."""
    if "hero" not in ctx.cache:
        ls = sorted(ctx.all("listings"), key=lambda l: -(l["units_30d"] or 0))
        total = sum(l["units_30d"] or 0 for l in ls) or 1
        acc, hero = 0, set()
        for l in ls:
            if acc / total >= ctx.cfg["catalogue"]["hero_share"]:
                break
            hero.add(l["sku"])
            acc += l["units_30d"] or 0
        ctx.cache["hero"] = hero
        ctx.cache["units_total"] = total
    return ctx.cache["hero"]


def units_share(ctx, sku_units):
    hero_skus(ctx)
    return (sku_units or 0) / ctx.cache["units_total"]


def min_viable_price(listing, cfg):
    """Cost + shipping + marketplace fee + advertising + target margin => minimum viable price."""
    fee = listing.get("fee_pct")
    fee = cfg["pricing"]["default_fee_pct"] if fee is None else fee
    denom = 1 - fee - cfg["targets"]["tacos"] - cfg["targets"]["target_margin"]
    if listing.get("cost") is None or denom <= 0.1:
        return None
    return math.ceil((listing["cost"] + (listing.get("shipping_cost") or 0)) / denom)
