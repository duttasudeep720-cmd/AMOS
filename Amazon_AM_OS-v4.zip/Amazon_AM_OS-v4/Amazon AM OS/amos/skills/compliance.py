"""Compliance department skills.

`validate_listing` is also used stand-alone by `python -m amos precheck` so a catalogue file
can be PASS/FAIL-checked BEFORE upload (the Kurta Sets scenario in the brief).
"""
import difflib
import re

from .base import Finding, skill, clamp, units_share, hero_skus


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


# common seller-entered variants -> the value Amazon's dropdown actually accepts
SYNONYMS = {
    "xxxl": "3XL", "xxxxl": "4XL", "2xl": "XXL", "extra large": "XL", "x-large": "XL", "free": "Free Size",
    "freesize": "Free Size", "one size": "Free Size", "three quarter": "3/4 Sleeve", "3/4th sleeve": "3/4 Sleeve",
    "three quarter sleeve": "3/4 Sleeve", "3/4": "3/4 Sleeve", "half sleeve": "Short Sleeve", "full sleeve": "Long Sleeve",
    "no sleeve": "Sleeveless", "cotton blended": "Cotton Blend", "silk blended": "Silk Blend",
}


def rules_for(cfg, category):
    rules = cfg["compliance"]["category_rules"]
    for name, r in rules.items():
        if _norm(name) == _norm(category):
            return r
    return None


def validate_listing(sku_row, cfg):
    """sku_row: dict with category, hsn, attrs (dict). Returns list of error dicts."""
    errors = []
    attrs = {_norm(k).replace(" ", "_"): v for k, v in (sku_row.get("attrs") or {}).items()}
    rules = rules_for(cfg, sku_row.get("category"))
    hsn = re.sub(r"\D", "", str(sku_row.get("hsn") or ""))

    if cfg["compliance"]["hsn_required"]:
        if not hsn:
            errors.append({"field": "hsn", "code": "HSN_MISSING", "message": "HSN code is missing"})
        elif len(hsn) not in (4, 6, 8):
            errors.append({"field": "hsn", "code": "HSN_FORMAT",
                           "message": f"HSN '{hsn}' must be 4, 6 or 8 digits"})
        elif rules and rules.get("hsn_prefixes") and not any(hsn.startswith(p) for p in rules["hsn_prefixes"]):
            errors.append({"field": "hsn", "code": "HSN_PREFIX",
                           "message": f"HSN {hsn} does not start with any of {rules['hsn_prefixes']} for {sku_row.get('category')}",
                           "suggestion": rules["hsn_prefixes"][0]})
    if not rules:
        return errors

    for a in rules.get("mandatory_attrs", []):
        if not _norm(attrs.get(a)):
            errors.append({"field": a, "code": "MISSING_ATTR", "message": f"Mandatory attribute '{a}' is missing"})
    for a, allowed in rules.get("allowed_values", {}).items():
        v = attrs.get(a)
        if _norm(v) and _norm(v) not in [_norm(x) for x in allowed]:
            syn = SYNONYMS.get(_norm(v))
            close = [syn] if syn in allowed else difflib.get_close_matches(str(v), allowed, n=1, cutoff=0.6)
            e = {"field": a, "code": "INVALID_VALUE",
                 "message": f"'{v}' is not an allowed value for '{a}'. Allowed: {', '.join(allowed)}"}
            if close:
                e["suggestion"] = close[0]
            errors.append(e)
    return errors


@skill("validate_catalogue", sources=["listings"],
       description="Validate mandatory attributes, dropdown values and HSN for every listing (pre-upload gate).")
def validate_catalogue(ctx):
    from ..ingest import parse_attrs
    ls = ctx.require("listings")
    hero_skus(ctx)
    out = []
    for l in ls:
        errs = validate_listing({"category": l["category"], "hsn": l["hsn"], "attrs": parse_attrs(l)}, ctx.cfg)
        if not errs:
            continue
        share = units_share(ctx, l["units_30d"])
        fixes = {e["field"]: e["suggestion"] for e in errs if e.get("suggestion")}
        out.append(Finding(
            type="catalogue_validation_failed", entity_type="sku", entity_id=l["sku"],
            title=f"{l['sku']}: {len(errs)} catalogue validation error(s) ({l['category']})",
            diagnosis="Listing fails marketplace/template rules: " + "; ".join(e["message"] for e in errs[:4]),
            recommendation={"action_type": "FIX_CATALOGUE_ATTRIBUTES",
                            "summary": "Correct the attributes/HSN listed in evidence and re-submit the catalogue.",
                            "params": {"sku": l["sku"], "errors": errs, "suggested_fixes": fixes}},
            evidence={"errors": errs, "asin": l["asin"], "category": l["category"]},
            impact=clamp(5 + share * 30 + len(errs) * 0.4), urgency=8, confidence=0.95,
            effort=clamp(1 + len(errs) * 0.5),
            metric={"name": "validation_errors", "value": len(errs), "better": "lower", "entity": l["sku"]}))
    return out
