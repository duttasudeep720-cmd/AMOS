"""Inventory + Orders & Operations department skills."""
import datetime as dt
import math

from .base import Finding, skill, clamp, inr, units_share, hero_skus, safe_div


@skill("detect_stockout_risk", sources=["inventory"],
       description="Stock cover vs supplier lead time -> proactive replenishment tasks.")
def detect_stockout_risk(ctx):
    cfg = ctx.cfg["inventory"]
    hero = hero_skus(ctx)
    listings = {l["sku"]: l for l in ctx.all("listings")}
    out = []
    for i in ctx.require("inventory"):
        adr = i["avg_daily_sales"] or 0
        if adr <= 0:
            continue
        lead = i["lead_time_days"] or cfg["default_lead_time_days"]
        cover = (i["stock"] or 0) / adr
        need_by = lead + cfg["min_buffer_days"]
        if cover >= need_by:
            continue
        qty = max(1, math.ceil(adr * (lead + cfg["target_cover_days"]) - (i["stock"] or 0) - (i["inbound"] or 0)))
        is_hero = i["sku"] in hero
        below_lead = cover < lead
        floor = 1 if (below_lead and is_hero) else (2 if below_lead else None)
        share = units_share(ctx, (listings.get(i["sku"]) or {}).get("units_30d") or adr * 30)
        out.append(Finding(
            type="stockout_risk", entity_type="sku", entity_id=i["sku"],
            title=f"{i['sku']}: {cover:.1f} days of stock left, lead time {lead} days" + (" (hero SKU)" if is_hero else ""),
            diagnosis=(f"Stock {i['stock']} / {adr:.1f} per day = {cover:.1f} days cover; replenishment lead time is {lead} days "
                       f"(+{cfg['min_buffer_days']} buffer). Stockout {'before' if below_lead else 'close to'} any new stock can land."),
            recommendation={"action_type": "CREATE_REPLENISHMENT",
                            "summary": f"Raise a replenishment for ~{qty} units (covers {cfg['target_cover_days']} days after lead time).",
                            "params": {"sku": i["sku"], "qty": qty, "inbound_counted": i["inbound"] or 0}},
            evidence={"stock": i["stock"], "avg_daily_sales": adr, "cover_days": round(cover, 1), "lead_time_days": lead,
                      "is_hero": is_hero, "inbound": i["inbound"]},
            impact=clamp(4 + share * 40 + (2 if below_lead else 0)), urgency=clamp(10 - cover / 2 + (1 if below_lead else 0)),
            confidence=0.9, effort=3, severity_floor=floor,
            metric={"name": "stock_cover_days", "value": round(cover, 1), "better": "higher", "entity": i["sku"]}))
    return out


@skill("detect_overstock", sources=["inventory"],
       description="Overstock / slow movers tying up capital (opportunity).")
def detect_overstock(ctx):
    cfg = ctx.cfg["inventory"]
    costs = {l["sku"]: l["cost"] or 0 for l in ctx.all("listings")}
    out = []
    for i in ctx.require("inventory"):
        stock, adr = i["stock"] or 0, i["avg_daily_sales"] or 0
        if stock < cfg["overstock_min_units"]:
            continue
        cover = stock / adr if adr > 0 else 999
        if cover < cfg["overstock_days"]:
            continue
        tied = stock * costs.get(i["sku"], 0)
        out.append(Finding(
            type="overstock", entity_type="sku", entity_id=i["sku"], kind="opportunity",
            title=f"{i['sku']}: {stock} units = {'>999' if cover >= 999 else round(cover)} days of stock ({inr(tied)} tied up)",
            diagnosis="Stock cover far above target; storage fees and capital lock-up risk. Consider a deal/coupon or liquidation.",
            recommendation={"action_type": "RUN_LIQUIDATION_PROMO", "summary": "Plan a coupon/deal to clear excess stock.",
                            "params": {"sku": i["sku"], "excess_units": int(stock - adr * cfg["target_cover_days"])}},
            evidence={"stock": stock, "avg_daily_sales": adr, "cover_days": None if cover >= 999 else round(cover), "capital_tied": tied},
            impact=clamp(2 + tied / 8000), urgency=3, confidence=0.7, effort=3.5,
            metric={"name": "stock_cover_days", "value": round(min(cover, 999), 1), "better": "lower", "entity": i["sku"]}))
    return out


@skill("detect_late_shipments", sources=["orders"],
       description="Unshipped orders past (or close to) their ship-by date.")
def detect_late_shipments(ctx):
    cfg = ctx.cfg["operations"]
    orders = ctx.require("orders", "status='Unshipped'")
    late, at_risk = [], []
    horizon = ctx.today + dt.timedelta(days=int(cfg["at_risk_hours"] // 24))
    for o in orders:
        if not o["ship_by"]:
            continue
        d = dt.date.fromisoformat(o["ship_by"][:10])
        if d < ctx.today:
            late.append(o)
        elif d <= horizon:
            at_risk.append(o)
    if not late and not at_risk:
        return []
    n_late, n_risk = len(late), len(at_risk)
    return [Finding(
        type="late_shipments", entity_type="account", entity_id="orders",
        title=f"{n_late} order(s) past ship-by date, {n_risk} due within {cfg['at_risk_hours']}h",
        diagnosis="Late dispatch hurts Late Dispatch Rate and Buy Box eligibility; ship or cancel-with-reason immediately.",
        recommendation={"action_type": "SHIP_ORDERS", "summary": "Dispatch the listed orders today.",
                        "params": {"late": [o["order_id"] for o in late], "due_soon": [o["order_id"] for o in at_risk]}},
        evidence={"late_orders": [{"order_id": o["order_id"], "sku": o["sku"], "ship_by": o["ship_by"]} for o in late[:20]],
                  "due_soon": len(at_risk)},
        impact=clamp(4 + n_late * 1.2 + n_risk * 0.3), urgency=clamp(6 + n_late), confidence=0.95, effort=2,
        severity_floor=1 if n_late else None,
        metric={"name": "late_orders", "value": n_late, "better": "lower", "entity": "orders"})]
