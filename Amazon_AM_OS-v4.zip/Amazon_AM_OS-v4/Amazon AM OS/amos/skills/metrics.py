"""Metric functions: recompute a finding's metric later so the Learning engine can compare before/after.
Each returns a float (or None if it cannot be computed from current data)."""
from .base import safe_div, min_viable_price


def _listing(ctx, sku):
    r = ctx.all("listings", "sku=?", (sku,))
    return r[0] if r else None


def campaign_acos(ctx, e):
    r = ctx.all("ad_campaigns", "campaign=?", (e,))
    if not r:
        return None
    v = safe_div(r[0]["spend"], r[0]["sales"])
    return v if v is not None else 9.99


def campaign_sales(ctx, e):
    r = ctx.all("ad_campaigns", "campaign=?", (e,))
    return r[0]["sales"] if r else None


def campaign_wasted_spend(ctx, e):
    cfg = ctx.cfg["ads"]
    ts = ctx.all("ad_search_terms", "campaign=?", (e,))
    return sum(t["spend"] for t in ts if (t["orders"] or 0) == 0 and (t["clicks"] or 0) >= cfg["wasted_min_clicks"]
               and (t["spend"] or 0) >= cfg["wasted_min_spend"])


def stock_cover_days(ctx, e):
    r = ctx.all("inventory", "sku=?", (e,))
    if not r or not r[0]["avg_daily_sales"]:
        return None
    return round(r[0]["stock"] / r[0]["avg_daily_sales"], 1)


def listing_conversion(ctx, e):
    l = _listing(ctx, e)
    return l["conversion_pct"] if l else None


def listing_gaps(ctx, e):
    from .catalogue import listing_gaps as gaps
    from .base import hero_skus
    l = _listing(ctx, e)
    return len(gaps(l, ctx.cfg, l["sku"] in hero_skus(ctx))) if l else None


def validation_errors(ctx, e):
    from ..ingest import parse_attrs
    from .compliance import validate_listing
    l = _listing(ctx, e)
    return len(validate_listing({"category": l["category"], "hsn": l["hsn"], "attrs": parse_attrs(l)}, ctx.cfg)) if l else None


def return_rate(ctx, e):
    l = _listing(ctx, e)
    if not l or not l["units_30d"]:
        return None
    q = sum(r["qty"] or 1 for r in ctx.all("returns", "sku=?", (e,)))
    return q / l["units_30d"]


def buy_box_pct(ctx, e):
    l = _listing(ctx, e)
    return l["buy_box_pct"] if l else None


def listing_active(ctx, e):
    l = _listing(ctx, e)
    return (1 if l["status"] == "active" else 0) if l else None


def late_orders(ctx, e):
    return len([o for o in ctx.all("orders", "status='Unshipped'") if o["ship_by"] and o["ship_by"][:10] < ctx.today.isoformat()])


def price_vs_floor(ctx, e):
    l = _listing(ctx, e)
    f = min_viable_price(l, ctx.cfg) if l else None
    return (l["price"] / f) if l and f else None


def price_vs_mrp(ctx, e):
    l = _listing(ctx, e)
    return (l["price"] / l["mrp"]) if l and l["mrp"] else None


def daily_sales(ctx, e):
    d = sorted(ctx.all("daily_performance"), key=lambda x: x["date"])
    return d[-1]["sales"] if d else None


def health_metric(ctx, e):
    r = ctx.all("health_metrics", "metric=?", (e,))
    return r[0]["value"] if r else None


METRICS = {f.__name__: f for f in (
    campaign_acos, campaign_sales, campaign_wasted_spend, stock_cover_days, listing_conversion, listing_gaps,
    validation_errors, return_rate, buy_box_pct, listing_active, late_orders, price_vs_floor, price_vs_mrp,
    daily_sales, health_metric)}


def compute(ctx, name, entity):
    fn = METRICS.get(name)
    if not fn:
        return None
    try:
        return fn(ctx, entity)
    except Exception:
        return None
