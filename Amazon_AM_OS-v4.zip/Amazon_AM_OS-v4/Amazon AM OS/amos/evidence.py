"""EVIDENCE LAYER.

Every AMOS Issue/Task should be able to answer:  "Why did AMOS create this?" and "What actual
seller data supports this?" - and the answer must always come from data AMOS actually has. This
module never fabricates a fact: every EvidenceItem is derived from a Finding's own `evidence`
dict, `metric`, `diagnosis` and `title` (see amos/skills/base.py's Finding dataclass) - the same
data the exception engine already stores as `issues.evidence_json`. This module just gives that
data a consistent, structured, queryable shape instead of an opaque blob, and makes it traceable
by issue id.

Design (kept intentionally small - see ARCHITECTURE.md/HANDOVER.md "Evidence Layer" session):
  - One new table, `evidence` (amos/core.py SCHEMA), one row per fact, FK'd to issues.id.
  - No duplicate data warehouse: rows hold references/snapshots (field, actual, expected,
    operator, observation, data_date) - never a copy of a whole report.
  - `source_kind`/`source_table`/`source_label` come from the skill's own already-declared
    `sources=[...]` (see skills/base.SkillDef) and amos/coverage.py's TABLES/LABELS maps - the
    same "what data does this skill need" declaration Coverage already reuses, so a new skill
    needs zero evidence-specific wiring to get a sensible source label.
  - Snapshot semantics: rows are replaced (delete+insert) only when an issue is inserted or
    refreshed while OPEN or on reopen (mirrors exactly how `issues.evidence_json` itself is
    written in engines/exception.py). A CLEARED issue is never touched again, so its evidence
    rows freeze at whatever was last true while it was open - satisfying section 7 of the brief
    ("historical evidence must survive changes to current source data") with no extra bookkeeping.

Public API:
    build_items(finding)                 -> list[EvidenceItem]   (pure, no DB access)
    save_issue_evidence(conn, issue_id, finding_or_items)         (writes; replaces existing rows)
    get_issue_evidence(conn, issue_id)   -> list[dict]            (reads)
    format_evidence(items, header=None)  -> str                  (human-readable)
"""
import dataclasses
from dataclasses import dataclass, field
from typing import Any, Optional

from . import core, coverage

try:
    from .skills.base import SKILLS
except ImportError:  # pragma: no cover - skills always import cleanly in practice
    SKILLS = {}

# Keys inside a Finding.evidence dict that mean "this is the report/snapshot date the numbers
# below came from" - if present, used as data_date; never guessed otherwise.
_DATE_KEYS = ("date", "report_date", "snapshot_date", "return_date", "order_date")

# List-shaped evidence keys that already carry per-item structure (field/issue or field/message) -
# these explode into one EvidenceItem per entry instead of one opaque item for the whole list.
_GAP_LIKE_KEYS = {
    "gaps": {"field": "field", "observation": "issue", "actual": "actual", "expected": "expected", "operator": "operator"},
    "errors": {"field": "field", "observation": "message", "operator": "code", "expected": "suggestion"},
}

_SCALAR_TYPES = (int, float, str, bool, type(None))


@dataclass
class EvidenceItem:
    source_kind: str = ""          # the skill's own logical kind, e.g. "listings" (see skills sources=[...])
    source_table: str = ""         # actual DB table the kind lives in, e.g. "listings" (may differ, e.g. "search_terms" -> "ad_search_terms")
    source_label: str = ""         # human label, e.g. "Amazon Category Listings Report"
    entity_type: str = ""          # sku | campaign | account | order_batch ...
    entity_id: str = ""
    field: Optional[str] = None
    actual: Any = None
    expected: Any = None
    operator: Optional[str] = None
    observation: str = ""
    data_date: Optional[str] = None

    def to_dict(self):
        return dataclasses.asdict(self)


def _source_info(skill_name):
    sd = SKILLS.get(skill_name)
    sources = sd.sources if sd else ()
    kind = sources[0] if sources else None
    table, _date_col = coverage.TABLES.get(kind, (kind, None))
    label = coverage.LABELS.get(kind, kind or skill_name or "unknown")
    return kind or "", table or "", label


def _data_date(evidence):
    if not isinstance(evidence, dict):
        return None
    for k in _DATE_KEYS:
        if evidence.get(k):
            return str(evidence[k])[:10]
    return None


def _scalar(v):
    return v if isinstance(v, _SCALAR_TYPES) else core.dumps(v)


def build_items(finding):
    """finding: a skills.base.Finding (post-run, with .skill/.department set by the director).
    Pure function - no DB access, never invents a value that wasn't already on the finding."""
    ev = finding.evidence or {}
    kind, table, label = _source_info(finding.skill)
    data_date = _data_date(ev)
    base = dict(source_kind=kind, source_table=table, source_label=label,
                entity_type=finding.entity_type, entity_id=finding.entity_id, data_date=data_date)

    items = []
    handled_keys = set()
    for key, spec in _GAP_LIKE_KEYS.items():
        entries = ev.get(key)
        if not isinstance(entries, list):
            continue
        handled_keys.add(key)
        for e in entries:
            if not isinstance(e, dict):
                continue
            items.append(EvidenceItem(
                **base,
                field=e.get(spec.get("field", "field")),
                actual=_scalar(e.get(spec.get("actual"))) if spec.get("actual") else None,
                expected=_scalar(e.get(spec.get("expected"))) if spec.get("expected") else None,
                operator=e.get(spec.get("operator")) if spec.get("operator") else None,
                observation=str(e.get(spec.get("observation", "observation"), "") or ""),
            ))

    for key, val in ev.items():
        if key in handled_keys or key in _DATE_KEYS:
            continue
        items.append(EvidenceItem(**base, field=key, actual=_scalar(val)))

    if not items:
        # Clean fallback (section 8 of the brief): no structured evidence dict on this finding yet -
        # never invent numbers, just carry the diagnosis/metric AMOS already computed.
        m = finding.metric or {}
        items.append(EvidenceItem(
            **base, field=m.get("name"), actual=_scalar(m.get("value")) if m else None,
            observation=finding.diagnosis or finding.title))
    return items


def save_issue_evidence(conn, issue_id, finding):
    """Replace this issue's evidence rows with the ones derived from `finding` right now.
    Call this whenever exception.process() creates/updates/reopens an issue (i.e. exactly when
    it also (re)writes issues.evidence_json) - never on clear, so cleared issues keep their last
    evidence untouched (see module docstring)."""
    items = finding if isinstance(finding, list) else build_items(finding)
    now = core.now()
    conn.execute("DELETE FROM evidence WHERE issue_id=?", (issue_id,))
    conn.executemany(
        """INSERT INTO evidence(issue_id, source_kind, source_table, source_label, entity_type,
           entity_id, field, actual_value, expected_value, operator, observation, data_date, created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        [(issue_id, it.source_kind, it.source_table, it.source_label, it.entity_type, it.entity_id,
          it.field, None if it.actual is None else str(it.actual), None if it.expected is None else str(it.expected),
          it.operator, it.observation, it.data_date, now) for it in items])
    conn.commit()
    return items


def get_issue_evidence(conn, issue_id):
    """Read-only: the structured evidence rows currently on file for this issue, oldest first."""
    return core.rows(conn, """SELECT source_kind, source_table, source_label, entity_type, entity_id,
        field, actual_value, expected_value, operator, observation, data_date, created_at
        FROM evidence WHERE issue_id=? ORDER BY id""", (issue_id,))


def format_evidence(items, header=None):
    """Human-readable text matching the brief's mock-up, e.g.:
        Source: Amazon Category Listings Report
        SKU: AT-MM-650G
        Images: 2
        Expected: 7
    `items` may be EvidenceItem objects (from build_items) or dict rows (from get_issue_evidence)."""
    def g(it, k):
        return it.get(k) if isinstance(it, dict) else getattr(it, k, None)

    if not items:
        return "No evidence recorded." if header is None else f"{header}\n\nNo evidence recorded."

    blocks = []
    for it in items:
        lines = []
        label = g(it, "source_label") or g(it, "source_kind")
        if label:
            lines.append(f"Source: {label}")
        etype, eid = g(it, "entity_type"), g(it, "entity_id")
        if etype and eid:
            lines.append(f"{etype.upper() if len(etype) <= 4 else etype.capitalize()}: {eid}")
        fld, actual, expected, op = g(it, "field"), g(it, "actual_value") or g(it, "actual"), \
            g(it, "expected_value") or g(it, "expected"), g(it, "operator")
        if fld and actual is not None:
            lines.append(f"{fld.replace('_', ' ').capitalize()}: {actual}")
        elif fld and not g(it, "observation"):
            lines.append(fld.replace("_", " ").capitalize())
        if expected is not None:
            lines.append(f"Expected: {expected}")
        obs = g(it, "observation")
        if obs and not (fld and actual is not None):
            lines.append(obs)
        elif obs and fld and actual is not None and obs not in lines:
            lines.append(obs)
        dd = g(it, "data_date")
        if dd:
            lines.append(f"Data date: {dd}")
        if lines:
            blocks.append("\n".join(lines))

    body = "\n\n".join(f"- {b.splitlines()[0]}" + ("\n  " + "\n  ".join(b.splitlines()[1:]) if len(b.splitlines()) > 1 else "")
                        for b in blocks) if len(blocks) > 1 else (blocks[0] if blocks else "")
    if len(blocks) == 1:
        text = blocks[0]
    else:
        text = "Evidence:\n" + body
    return f"{header}\n\n{text}" if header else text
