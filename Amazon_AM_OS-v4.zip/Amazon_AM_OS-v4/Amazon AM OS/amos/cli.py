"""AMOS command line interface.  Run `python -m amos <command> --help` for details on any command.

Every command opens the sqlite DB at $AMOS_DB (default data/amos.db), does one thing, and exits -
this is meant to be scriptable (cron, CI, a Slack bot) as much as it is meant for a human to type.
"""
import argparse
import json
import sys

from . import core, coverage as coverage_mod, demo, evidence as evidence_mod, ingest, reporting, workqueue
from .director import AccountDirector


def _accounts(conn):
    return core.rows(conn, "SELECT a.id, c.name AS client, a.marketplace, a.store FROM accounts a JOIN clients c ON c.id=a.client_id ORDER BY a.id")


def cmd_seed(args, conn):
    aid = demo.seed(conn, args.sample_dir, phase=args.phase)
    print(f"Seeded demo account #{aid} ({demo.CLIENT}) with sample CSVs in {args.sample_dir}")
    print("Run `python -m amos cycle --account", aid, "` to have the Account Director analyse it.")


def cmd_demo_fix(args, conn):
    account = core.get_account(conn, args.account)
    applied = demo.simulate_fixes(conn, account)
    print(f"Simulated the marketplace reacting to {len(applied)} executed task(s):")
    for tid, action in applied:
        print(f"  #{tid}  {action}")
    if not applied:
        print("  (nothing to simulate - execute some tasks first with `amos execute`)")


def cmd_accounts(args, conn):
    for a in _accounts(conn):
        print(f"#{a['id']:<3} {a['client']:<28} {a['marketplace']:<14} {a['store'] or ''}")


def cmd_ingest(args, conn):
    r = ingest.ingest_file(conn, args.account, args.kind, args.file)
    print(f"{r['kind']}: {r['rows']} row(s) ingested, {r['skipped']} skipped (no key column).")


def cmd_precheck(args, conn):
    account = core.get_account(conn, args.account)
    rows = ingest.read_table(args.file)
    result = ingest.precheck_rows(rows, account["config"], default_category=args.category)
    print(f"Checked {result['checked']} row(s): {result['checked'] - result['failed']} PASS, {result['failed']} FAIL")
    for r in result["rows"]:
        if r["status"] == "FAIL":
            print(f"\n  FAIL  {r['sku']}  ({r['category']})")
            for e in r["errors"]:
                sug = f"  -> suggest: {e['suggestion']}" if e.get("suggestion") else ""
                print(f"        [{e['code']}] {e['message']}{sug}")
    sys.exit(0 if result["pass"] else 1)


def cmd_cycle(args, conn):
    d = AccountDirector(conn, args.account)
    s = d.run_cycle(trigger=args.trigger)
    print(json.dumps({k: v for k, v in s.items() if k != "skills_run"}, indent=2, default=str))
    if s["errors"]:
        print(f"\n{len(s['errors'])} skill(s) errored (see audit_log): {list(s['errors'])}", file=sys.stderr)


def cmd_dashboard(args, conn):
    print(json.dumps(reporting.dashboard(conn, args.account), indent=2, default=str))


def cmd_issues(args, conn):
    for i in reporting.issues_list(conn, args.account, status=args.status):
        print(f"P{i['priority']} [{i['department']:<12}] #{i['id']:<5} {i['title']}")


def cmd_tasks(args, conn):
    from .engines import tasks as tasks_engine
    for t in tasks_engine.list_tasks(conn, args.account, status=args.status, department=args.department):
        print(f"P{t['priority']} L{t['autonomy_level']} [{t['status']:<17}] #{t['id']:<5} {t['title']}")


def cmd_approve(args, conn):
    d = AccountDirector(conn, args.account)
    print(json.dumps(d.approve(args.task, note=args.note or ""), indent=2, default=str))


def cmd_reject(args, conn):
    d = AccountDirector(conn, args.account)
    print(json.dumps(d.reject(args.task, note=args.note or ""), indent=2, default=str))


def cmd_execute(args, conn):
    d = AccountDirector(conn, args.account)
    r = d.execute(args.task, via=args.via, note=args.note or "")
    print(json.dumps(r, indent=2, default=str))


def cmd_brief(args, conn):
    print((reporting.daily_brief_md if args.period == "daily" else reporting.weekly_report_md)(conn, args.account))


def cmd_coverage(args, conn):
    account = core.get_account(conn, args.account)
    cov = coverage_mod.get_account_coverage(conn, args.account)
    print("AMOS DATA COVERAGE")
    print(f"Account: {account['client_name']}")
    print()
    for line in coverage_mod.summary_lines(cov):
        print(line)
    lims = coverage_mod.limitations(cov)
    if lims:
        print()
        print("Analysis limitations:")
        for lim in lims:
            print(f"- {lim['message']}")


def cmd_evidence(args, conn):
    iss = core.row(conn, "SELECT id, title, account_id FROM issues WHERE id=?", (args.issue,))
    if not iss or iss["account_id"] != args.account:
        print(f"No issue #{args.issue} found for account {args.account}", file=sys.stderr)
        sys.exit(1)
    items = evidence_mod.get_issue_evidence(conn, args.issue)
    print("AMOS EVIDENCE")
    print()
    print(f"Issue: #{iss['id']}")
    print(iss["title"])
    print()
    print(evidence_mod.format_evidence(items))


def cmd_queue(args, conn):
    try:
        sys.stdout.reconfigure(errors="replace")   # issue titles can contain currency symbols; never crash a legacy console
    except (AttributeError, ValueError):
        pass
    try:
        q = workqueue.get_work_queue(conn, args.account, status=args.status)
    except (KeyError, ValueError) as e:
        print(e.args[0] if e.args else e, file=sys.stderr)
        sys.exit(1)
    print(workqueue.format_queue_text(q))


def cmd_org(args, conn):
    print(json.dumps(__import__("amos.org", fromlist=["describe"]).describe(), indent=2, default=str))


def cmd_serve(args, conn):
    from .server import serve
    serve(args.host, args.port)


def main(argv=None):
    p = argparse.ArgumentParser(prog="python -m amos", description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("seed", help="create a demo client account with realistic sample data")
    s.add_argument("--sample-dir", default="samples")
    s.add_argument("--phase", type=int, default=1, choices=[1, 2, 3, 4])
    s.set_defaults(func=cmd_seed, needs_account=False)

    s = sub.add_parser("demo-fix", help="[demo only] simulate the marketplace reacting to executed tasks")
    s.add_argument("--account", type=int, required=True)
    s.set_defaults(func=cmd_demo_fix)

    s = sub.add_parser("accounts", help="list client accounts")
    s.set_defaults(func=cmd_accounts, needs_account=False)

    s = sub.add_parser("ingest", help="ingest one report file for an account")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--kind", required=True, choices=ingest.KINDS)
    s.add_argument("file")
    s.set_defaults(func=cmd_ingest)

    s = sub.add_parser("precheck", help="PASS/FAIL a catalogue file against compliance rules BEFORE upload")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--category", help="default category if the file has no category column")
    s.add_argument("file")
    s.set_defaults(func=cmd_precheck)

    s = sub.add_parser("cycle", help="run one Account Director cycle: detect -> issues -> tasks -> verify -> measure")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--trigger", default="manual")
    s.set_defaults(func=cmd_cycle)

    s = sub.add_parser("dashboard", help="print the dashboard JSON for an account")
    s.add_argument("--account", type=int, required=True)
    s.set_defaults(func=cmd_dashboard)

    s = sub.add_parser("issues", help="list issues")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--status", default="open")
    s.set_defaults(func=cmd_issues)

    s = sub.add_parser("tasks", help="list tasks")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--status", default="active")
    s.add_argument("--department")
    s.set_defaults(func=cmd_tasks)

    s = sub.add_parser("approve", help="approve a pending task")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("task", type=int)
    s.add_argument("--note")
    s.set_defaults(func=cmd_approve)

    s = sub.add_parser("reject", help="reject a pending task")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("task", type=int)
    s.add_argument("--note")
    s.set_defaults(func=cmd_reject)

    s = sub.add_parser("execute", help="execute a ready/human-only task")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("task", type=int)
    s.add_argument("--via", default="manual", choices=["manual", "agent"])
    s.add_argument("--note")
    s.set_defaults(func=cmd_execute)

    s = sub.add_parser("brief", help="print the daily brief or weekly report as Markdown")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--period", default="daily", choices=["daily", "weekly"])
    s.set_defaults(func=cmd_brief)

    s = sub.add_parser("coverage", help="show data coverage (available/stale/missing) and any analysis limitations")
    s.add_argument("--account", type=int, required=True)
    s.set_defaults(func=cmd_coverage)

    s = sub.add_parser("evidence", help="show the structured evidence behind one issue")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--issue", type=int, required=True)
    s.set_defaults(func=cmd_evidence)

    s = sub.add_parser("queue", help="the Account Manager's daily work queue (same data as the dashboard)")
    s.add_argument("--account", type=int, required=True)
    s.add_argument("--status", default="attention", choices=workqueue.FILTERS,
                   help="which tasks to list (default: everything that needs a person)")
    s.set_defaults(func=cmd_queue)

    s = sub.add_parser("org", help="print the org chart + skill registry as JSON")
    s.set_defaults(func=cmd_org, needs_account=False)

    s = sub.add_parser("serve", help="start the dashboard web server")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8765)
    s.set_defaults(func=cmd_serve, needs_account=False)

    args = p.parse_args(argv)
    conn = core.connect()
    try:
        args.func(args, conn)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
