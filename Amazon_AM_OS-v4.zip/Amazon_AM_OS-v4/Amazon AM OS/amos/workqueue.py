"""ACCOUNT DASHBOARD + DAILY AM WORK QUEUE - the service layer behind the Account Manager's daily screen.

This module owns NO business logic and NO tables. It only *composes* things AMOS already decided:

    tasks / priorities / due dates   -> engines/tasks.py + engines/priority.py   (one task system, one ranking)
    approval + execution rules       -> engines/policy.py + engines/execution.py (the UI never decides, it asks)
    "why did AMOS create this?"      -> evidence.py (rows) formatted by evidence.format_evidence
    what data exists / is missing    -> coverage.py
    department status tiles, metrics -> reporting.dashboard()
    recent activity                  -> the existing audit_log table

Layering:   server.py  ->  workqueue.py  ->  reporting / engines / coverage / evidence  ->  DB

Public API:
    get_work_queue(conn, account_id, status="attention") -> dict   (the consolidated dashboard payload)
    task_view(conn, task_id)                             -> dict   (one enriched task, for the detail modal)
    format_queue_text(queue)                             -> str    (plain-text version, used by `amos queue`)
"""
import datetime as dt
import json
import re

from . import core, coverage, evidence, org, reporting
from .engines import policy, priority, tasks as tasks_engine
from .skills import SKILLS

# Tasks that need a person to do something. Everything else is either waiting on the marketplace
# (executed / verified) or finished (closed / rejected) and lives behind a filter or in Recent activity.
ATTENTION = ("pending_approval", "pending_decision", "human_only", "ready")
APPROVAL = ("pending_approval", "pending_decision")           # the two states the approve/reject endpoints accept
CLOSED = ("closed", "rejected")
FILTERS = ("attention", "pending_approval", "pending_decision", "human_only", "ready",
           "executed", "verified", "closed")
HISTORY_LIMIT = 50                                            # cap for the 'closed' history view

STATUS_LABELS = {
    "pending_approval": "Pending approval",
    "pending_decision": "Pending decision",
    "human_only": "Human action required",
    "ready": "Ready to execute",
    "executed": "Executed, awaiting verification",
    "verified": "Verified, measuring result",
    "closed": "Closed",
    "rejected": "Rejected",
}

# What each autonomy level means (from engines/policy.py's own docstring), used only to phrase the generic
# "default policy for X" reason in plain language. Specific engine reasons (e.g. bid-limit breaches) are shown verbatim.
_LEVEL_WORDS = {0: "fully automatic", 1: "a small, bounded change AMOS may make within its limits",
                2: "AMOS recommends and you approve", 3: "AMOS detects and you decide", 4: "only a person can act"}
_PAIR = re.compile(r"^([A-Za-z][A-Za-z0-9 %/()_-]{0,30}): (.*)$")
_TARGET_OPS = ("<", ">", "<=", ">=", "==", "!=")               # operators where `expected` is a real target


# ---------------------------------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------------------------------
def _date(s):
    try:
        return dt.date.fromisoformat(str(s)[:10])
    except (TypeError, ValueError):
        return None


def _sort_key(t):
    """priority (existing bucket) -> due date -> existing score (high first) -> id. No new ranking formula:
    the first and third keys are exactly the order tasks.list_tasks already uses; due date is the tie-breaker."""
    return (t["priority"] or 9, t["due_date"] or "9999-12-31", -(t["score"] or 0), t["id"])


def _due(due_date, today):
    d = _date(due_date)
    if d is None:
        return None, "No due date"
    n = (d - today).days
    if n < 0:
        return n, f"Overdue by {-n} day{'s' if n != -1 else ''}"
    if n == 0:
        return n, "Due today"
    if n == 1:
        return n, "Due tomorrow"
    return n, f"Due in {n} days"


def _short(text, n):
    text = " ".join(str(text or "").split())
    return text if len(text) <= n else text[: n - 3].rstrip() + "..."


# ---------------------------------------------------------------------------------------------------
# evidence -> summary / display lines (all formatting stays in Python; the browser only renders)
# ---------------------------------------------------------------------------------------------------
def _json_value(v):
    """Evidence stores list/dict facts as one JSON string (evidence._scalar). -> parsed list/dict, else None."""
    if isinstance(v, str) and v[:1] in "[{":
        try:
            parsed = json.loads(v)
            return parsed if isinstance(parsed, (list, dict)) else None
        except ValueError:
            return None
    return None


def _nice(v):
    """Human-friendly number for one-line summaries (2576.0 -> 2,576; 0.49538 -> 0.4954). Non-numbers unchanged."""
    s = str(v)
    try:
        f = float(s)
    except ValueError:
        return s
    if s.lstrip("-").isdigit():
        return s
    return "{:,.0f}".format(f) if abs(f) >= 100 else "{:.4g}".format(f)


def evidence_summary(rows):
    """One short line for a queue row, e.g. 'Images: 2 / target 7 (+3 more)'. Built only from stored rows."""
    if not rows:
        return ""
    label = lambda r: r["field"].replace("_", " ").capitalize()
    shown = 1
    lead = next((r for r in rows if r.get("operator") in _TARGET_OPS and r.get("field")
                 and r.get("actual_value") is not None and r.get("expected_value") is not None), None)
    if lead:
        text = f"{label(lead)}: {_nice(lead['actual_value'])} / target {_nice(lead['expected_value'])}"
    else:
        obs = next((r for r in rows if (r.get("observation") or "").strip()), None)
        if obs:
            text = obs["observation"]
        else:
            pairs = []
            for r in rows:
                if not r.get("field") or r.get("actual_value") is None:
                    continue
                parsed = _json_value(r["actual_value"])
                val = _nice(r["actual_value"]) if parsed is None else f"{len(parsed)} item{'s' if len(parsed) != 1 else ''}"
                pairs.append(f"{label(r)}: {val}")
                if len(pairs) == 2:
                    break
            shown = max(len(pairs), 1)
            text = "; ".join(pairs) or "Evidence recorded"
    text = _short(text, 110)
    more = len(rows) - shown
    return text + (f" (+{more} more)" if more > 0 else "")


def _flat(x):
    return _short(", ".join(f"{k}: {v}" for k, v in x.items()) if isinstance(x, dict) else x, 160)


def evidence_display(rows):
    """Per-item [{label,value[,detail]} | {text}] lines, produced by the SAME formatter the CLI uses
    (evidence.format_evidence) so the dashboard can never drift from `amos evidence`. A list/dict fact
    (stored as JSON) becomes '3 items' plus a readable `detail` list instead of a wall of JSON."""
    out = []
    for r in rows:
        lines = []
        for ln in evidence.format_evidence([r]).splitlines():
            ln = ln.strip()
            if not ln or ln in ("Evidence:", "No evidence recorded."):
                continue
            m = _PAIR.match(ln)
            if not m:
                lines.append({"text": ln})
                continue
            parsed = _json_value(m.group(2))
            if isinstance(parsed, list):
                lines.append({"label": m.group(1), "value": f"{len(parsed)} item{'s' if len(parsed) != 1 else ''}",
                              "detail": [_flat(x) for x in parsed[:10]] + ([f"... and {len(parsed) - 10} more"] if len(parsed) > 10 else [])})
            elif isinstance(parsed, dict):
                lines.append({"label": m.group(1), "value": "1 record", "detail": [_flat(parsed)]})
            else:
                lines.append({"label": m.group(1), "value": m.group(2)})
        if lines:
            out.append({"source_label": r.get("source_label"), "entity_type": r.get("entity_type"),
                        "entity_id": r.get("entity_id"), "data_date": r.get("data_date"), "lines": lines})
    return out


# ---------------------------------------------------------------------------------------------------
# one task -> the enriched dict the UI renders
# ---------------------------------------------------------------------------------------------------
class _Ctx:
    """Per-request caches so building a 100-row queue is a handful of cheap SQLite lookups, not a tangle."""

    def __init__(self, conn, account, cov=None):
        self.conn, self.account, self.cov = conn, account, cov
        self.today = core.today()
        self.dept_names = {d.key: d.name for d in org.ORG}
        self._issues = {}

    def issue(self, issue_id):
        if issue_id is None:
            return None
        if issue_id not in self._issues:
            self._issues[issue_id] = core.row(self.conn, """SELECT id, title, type, kind, status, department, skill,
                entity_type, entity_id, diagnosis, recommendation_json, first_seen, last_seen
                FROM issues WHERE id=?""", (issue_id,))
        return self._issues[issue_id]


def _policy_reason(t):
    r = t.get("autonomy_reason") or ""
    if r.startswith("default policy for"):
        lvl = t["autonomy_level"]
        return f"{(t['action_type'] or 'This action').replace('_', ' ').capitalize()} is a level {lvl} action: {_LEVEL_WORDS.get(lvl, 'see policy')}."
    return r


def _approval(t):
    lvl, st = t["autonomy_level"], t["status"]
    if st == "rejected":
        state, label = "rejected", "Rejected"
    elif st == "pending_approval":
        state, label = "pending", "Required - waiting for your approval (L2)"
    elif st == "pending_decision":
        state, label = "pending", "Required - waiting for your decision (L3)"
    elif st == "human_only":
        state, label = "human_only", "Human-only (L4) - AMOS will not act on this itself"
    elif lvl is not None and lvl >= 2:
        state, label = "cleared", f"Cleared (L{lvl}) - approved before execution"
    else:
        state, label = "not_required", f"Not required (L{lvl if lvl is not None else 0}) - within automatic limits"
    return {"required": lvl in (2, 3), "state": state, "label": label}


def _execution(t, cfg):
    """Facts + one plain sentence about how this task can be executed. Rules come from policy.py, not here."""
    mode, phase = cfg["execution"]["mode"], cfg["phase"]
    st, lvl, action = t["status"], t["autonomy_level"], t["action_type"]
    agent = bool(policy.agent_may_execute(lvl if lvl is not None else 3, action, phase, cfg))
    parts = ["Dry-run mode: nothing is sent to Amazon." if mode == "dry_run"
             else "Live mode: agent actions go through the marketplace connector."]
    if st in APPROVAL:
        parts.append("It cannot be executed until it is approved.")
    elif st in ("ready", "human_only"):
        parts.append(f"Policy allows an agent to run this automatically once ready (phase {phase})." if agent
                     else f"Phase {phase}, L{lvl}: a person does the work, then records it as executed here.")
    elif st == "executed":
        parts.append("Executed. Waiting for fresh data to confirm the issue has cleared.")
    elif st == "verified":
        parts.append("Verified. AMOS is measuring the result.")
    return {"mode": mode, "phase": phase, "agent_may_execute": agent,
            "can_execute": st in ("ready", "human_only"), "text": " ".join(parts)}


def _task_coverage(iss, cov):
    """Coverage of the data kinds the detecting skill declared in sources=[...] (the same declaration
    coverage.py and evidence.py already use)."""
    sd = SKILLS.get(iss["skill"]) if iss and iss.get("skill") else None
    out = []
    for kind in (sd.sources if sd else ()):
        c = (cov or {}).get(kind)
        if c:
            out.append({"kind": kind, "label": c["label"], "status": c["status"], "row_count": c["row_count"],
                        "latest_date": c["latest_date"], "age_days": c["age_days"]})
    return out


def _build_item(ctx, t, detail=False):
    conn, account = ctx.conn, ctx.account
    iss = ctx.issue(t.get("issue_id"))
    rec = core.loads(iss["recommendation_json"], {}) if iss else {}
    rows = evidence.get_issue_evidence(conn, t["issue_id"]) if t.get("issue_id") else []
    st = t["status"]
    due_in, due_label = _due(t.get("due_date"), ctx.today)
    last = core.row(conn, "SELECT stage, actor, note, at FROM task_history WHERE task_id=? ORDER BY id DESC LIMIT 1", (t["id"],))

    # Why is a human needed? Normally the policy reason recorded at creation. If the task bounced back to a
    # human (failed verification / blocked by a guardrail) the latest history note is the truer reason.
    returned = bool(st in APPROVAL and last and last["stage"] in ("VERIFY", "EXECUTE"))
    policy_reason = _policy_reason(t)
    reason = last["note"] if returned else policy_reason

    item = {
        "id": t["id"], "priority": t["priority"], "priority_label": priority.LABELS.get(t["priority"], "Unranked"),
        "title": t["title"], "department": t["department"],
        "department_name": ctx.dept_names.get(t["department"], t["department"]),
        "status": st, "status_label": STATUS_LABELS.get(st, st), "outcome": t.get("outcome"),
        "autonomy_level": t["autonomy_level"], "reason": reason, "policy_reason": policy_reason, "returned_to_human": returned,
        "due_date": t.get("due_date"), "due_in_days": due_in, "due_label": due_label, "score": t.get("score"),
        "action_type": t["action_type"], "recommended_action": rec.get("summary") or "",
        "account": {"id": account["id"], "client": account["client_name"], "marketplace": account["marketplace"]},
        "issue": None if not iss else {"id": iss["id"], "title": iss["title"], "type": iss["type"],
                                       "kind": iss["kind"], "status": iss["status"]},
        "evidence": {"available": bool(rows), "count": len(rows), "summary": evidence_summary(rows),
                     "sources": sorted({r["source_label"] for r in rows if r.get("source_label")})},
        "approval": _approval(t),
        "execution": _execution(t, account["config"]),
        # Buttons the UI may offer. These only mirror which statuses the task engine accepts; the backend
        # re-checks on every call and its refusal reason is shown verbatim.
        "can": {"approve": st in APPROVAL, "reject": st in tasks_engine.PRE_EXEC, "execute": st in ("ready", "human_only")},
        "attempts": t.get("attempts") or 0,
        "created_at": t.get("created_at"), "executed_at": t.get("executed_at"), "closed_at": t.get("closed_at"),
    }
    if detail:
        if iss:
            item["issue"].update(diagnosis=iss["diagnosis"], department=iss["department"], skill=iss["skill"],
                                 entity_type=iss["entity_type"], entity_id=iss["entity_id"],
                                 first_seen=iss["first_seen"], last_seen=iss["last_seen"])
        item["evidence"]["items"] = evidence_display(rows)
        item["coverage"] = _task_coverage(iss, ctx.cov)
    return item


def task_view(conn, task_id):
    """Enriched view of a single task for the detail modal (any status, any account)."""
    t = core.row(conn, "SELECT * FROM tasks WHERE id=?", (task_id,))
    if not t:
        raise KeyError(f"task {task_id} not found")
    account = core.get_account(conn, t["account_id"])
    ctx = _Ctx(conn, account, cov=coverage.get_account_coverage(conn, account["id"]))
    return _build_item(ctx, t, detail=True)


# ---------------------------------------------------------------------------------------------------
# overview / state / activity
# ---------------------------------------------------------------------------------------------------
def _overview(conn, account_id, open_issue_n, open_task_n):
    perf = reporting._perf_windows(conn, account_id)         # rows ordered by date, existing helper
    metrics = []
    if perf:
        last = perf[-1]
        latest = _date(last["date"])
        window = [r for r in perf if latest and _date(r["date"]) and _date(r["date"]) > latest - dt.timedelta(days=7)]
        for key, label, kind in (("sales", "Sales", "money"), ("orders", "Orders", "count"),
                                 ("sessions", "Sessions", "count"), ("ad_spend", "Ad spend", "money"),
                                 ("ad_sales", "Ad sales", "money")):
            metrics.append({"key": key, "label": label, "kind": kind, "value": last[key],
                            "window_total": reporting._sum(window, key) if window else None,
                            "window_days": len(window)})
        as_of = last["date"]
    else:
        as_of = None
        for key, label, kind in (("sales", "Sales", "money"), ("orders", "Orders", "count"),
                                 ("sessions", "Sessions", "count"), ("ad_spend", "Ad spend", "money"),
                                 ("ad_sales", "Ad sales", "money")):
            metrics.append({"key": key, "label": label, "kind": kind, "value": None, "window_total": None, "window_days": 0})
    return {"as_of": as_of, "has_data": bool(perf), "metrics": metrics,
            "open_issues": open_issue_n, "open_tasks": open_task_n}


def _activity_text(a, detail):
    act, eid, actor = a["action"], a["entity_id"], a["actor"]
    note = _short(detail.get("note"), 80)
    if act == "task_created":
        return f"Task #{eid} created"
    if act == "task_approved":
        return f"Task #{eid} approved" + (f": {note}" if note and note != "Approved" else "")
    if act == "task_rejected":
        return f"Task #{eid} rejected" + (f": {note}" if note else "")
    if act == "task_executed":
        return f"Task #{eid} executed ({detail.get('mode', 'manual')})" + (" by agent" if actor == "agent" else "")
    if act == "agent_blocked":
        return f"Agent blocked on task #{eid}: {_short(detail.get('reason'), 100)}"
    if act == "connector_error":
        return f"Connector error on task #{eid}: {_short(detail.get('error'), 100)}"
    if act == "skill_error":
        return f"Skill {eid} failed: {_short(detail.get('error'), 100)}"
    if act == "cycle_completed":
        bits = [f"{detail[k]} {lbl}" for k, lbl in (("new_issues", "new"), ("reopened", "reopened"), ("cleared", "cleared"),
                                                     ("tasks_created", "task(s) created"), ("verified", "verified"))
                if detail.get(k)]
        return "Cycle completed" + (": " + ", ".join(bits) if bits else ": no changes")
    if act == "data_ingested":
        return f"{coverage.LABELS.get(eid, eid)} data imported ({detail.get('rows', 0)} rows)"
    if act == "account_created":
        return "Account created"
    if act == "config_updated":
        return "Account settings updated"
    return act.replace("_", " ").capitalize()


def recent_activity(conn, account_id, limit=15):
    out = []
    for a in core.rows(conn, """SELECT id, actor, action, entity_type, entity_id, detail_json, at
                                FROM audit_log WHERE account_id=? ORDER BY id DESC LIMIT ?""", (account_id, limit)):
        detail = core.loads(a["detail_json"], {}) or {}
        task_id = int(a["entity_id"]) if a["entity_type"] == "task" and str(a["entity_id"]).isdigit() else None
        out.append({"at": a["at"], "actor": a["actor"], "action": a["action"], "task_id": task_id,
                    "text": _activity_text(a, detail)})
    return out


# ---------------------------------------------------------------------------------------------------
# the consolidated payload
# ---------------------------------------------------------------------------------------------------
def get_work_queue(conn, account_id, status="attention"):
    """Everything the AM's daily screen needs in one call. `status` picks which tasks fill `work_queue`
    (default: everything that needs a person); `approvals`, `status_counts` and the rest never depend on it."""
    if status not in FILTERS:
        raise ValueError(f"unknown status filter '{status}' (use one of: {', '.join(FILTERS)})")

    account = core.get_account(conn, account_id)              # KeyError -> 404
    dash = reporting.dashboard(conn, account_id)              # tiles, coverage, limitations, active tasks - reused as-is
    active = dash["tasks"]
    ctx = _Ctx(conn, account, cov=dash["data_coverage"])

    counts = {"attention": sum(1 for t in active if t["status"] in ATTENTION)}
    for s in ("pending_approval", "pending_decision", "human_only", "ready", "executed", "verified"):
        counts[s] = sum(1 for t in active if t["status"] == s)
    counts["closed"] = core.row(conn, f"SELECT COUNT(*) n FROM tasks WHERE account_id=? AND status IN ({','.join('?' * len(CLOSED))})",
                                (account_id,) + CLOSED)["n"]

    if status == "attention":
        picked = [t for t in active if t["status"] in ATTENTION]
    elif status == "closed":
        picked = []
        for s in CLOSED:
            picked += tasks_engine.list_tasks(conn, account_id, status=s, limit=HISTORY_LIMIT)
        picked.sort(key=lambda t: t.get("closed_at") or "", reverse=True)
        picked = picked[:HISTORY_LIMIT]
    else:
        picked = [t for t in active if t["status"] == status]
    if status != "closed":
        picked = sorted(picked, key=_sort_key)

    attention = [t for t in active if t["status"] in ATTENTION]
    approvals = sorted((t for t in attention if t["status"] in APPROVAL), key=_sort_key)

    issues = core.rows(conn, "SELECT priority, kind FROM issues WHERE account_id=? AND status='open'", (account_id,))
    real = [i for i in issues if i["kind"] == "issue"]
    state = {
        "open_issues": len(real), "critical": sum(1 for i in real if i["priority"] == 1),
        "high": sum(1 for i in real if i["priority"] == 2), "opportunities": len(issues) - len(real),
        "awaiting_you": len(approvals), "pending_approval": counts["pending_approval"],
        "pending_decision": counts["pending_decision"], "human_only": counts["human_only"],
        "data_limitations": len(dash["coverage_limitations"]),
        "data_missing": sum(1 for c in dash["data_coverage"].values() if c["status"] == "missing"),
        "data_stale": sum(1 for c in dash["data_coverage"].values() if c["status"] == "stale"),
    }

    info = dict(dash["account"])
    info.update(currency=account.get("currency") or "INR", today=ctx.today.isoformat())

    return {
        "account": info,
        "overview": _overview(conn, account_id, state["open_issues"], dash["open_tasks"]),
        "state": state,
        "departments": dash["tiles"],
        "coverage": dash["data_coverage"],
        "limitations": dash["coverage_limitations"],
        "buckets": {p: sum(1 for t in attention if t["priority"] == p) for p in (1, 2, 3, 4)},
        "bucket_labels": priority.LABELS,
        "filter": status, "status_counts": counts, "status_labels": STATUS_LABELS,
        "work_queue": [_build_item(ctx, t) for t in picked],
        "approvals": [_build_item(ctx, t) for t in approvals],
        "recent_activity": recent_activity(conn, account_id),
        "generated_at": core.now(),
    }


# ---------------------------------------------------------------------------------------------------
# plain-text rendering (CLI `amos queue`) - ASCII layout characters so it prints on a Windows console
# ---------------------------------------------------------------------------------------------------
def format_queue_text(q):
    a, s, ov = q["account"], q["state"], q["overview"]
    lines = ["AMOS DAILY WORK QUEUE", f"Account: {a['client']} ({a['marketplace']}) | phase {a['phase']} | {a['mode']} | {a['currency']}", ""]
    if ov["has_data"]:
        def _n(v):
            return "-" if v is None else "{:,.0f}".format(v)
        lines.append("Overview (latest day %s): " % ov["as_of"] + " | ".join(
            "%s %s" % (m["label"], _n(m["value"])) for m in ov["metrics"]))
    else:
        lines.append("Overview: no daily performance data yet")
    lines.append(f"State: {s['open_issues']} open issues | {s['critical']} critical | {s['high']} high | "
                 f"{s['awaiting_you']} awaiting you | {s['data_limitations']} data limitation(s)")
    lines.append("")
    label = {"attention": "NEEDS ATTENTION"}.get(q["filter"], q["status_labels"].get(q["filter"], q["filter"]).upper())
    lines.append(f"{label} ({len(q['work_queue'])})")
    if not q["work_queue"]:
        lines.append("  Nothing here.")
    last_p = None
    for it in q["work_queue"]:
        if q["filter"] != "closed" and it["priority"] != last_p:
            last_p = it["priority"]
            lines += ["", f"[{it['priority_label'].upper()}]"]
        lines.append(f"  #{it['id']:<4} {it['title']}")
        lines.append(f"        {it['status_label']} | L{it['autonomy_level']} | {it['due_label']} | {it['department_name']}")
        lines.append(f"        Evidence: {it['evidence']['summary'] or 'not recorded'}")
        if it["recommended_action"]:
            lines.append(f"        Recommended: {_short(it['recommended_action'], 100)}")
    if q["approvals"]:
        lines += ["", f"APPROVALS REQUIRED ({len(q['approvals'])})"]
        lines += [f"  Task #{it['id']}  {it['priority_label']}  {it['title']}" for it in q["approvals"]]
    if q["limitations"]:
        lines += ["", "DATA LIMITATIONS"] + [f"  {l['message']}" for l in q["limitations"]]
    if q["recent_activity"]:
        lines += ["", "RECENT ACTIVITY"] + [f"  {a_['at'][11:16]}  {a_['text']}" for a_ in q["recent_activity"][:8]]
    return "\n".join(lines)
