# AMOS Architecture Brief

This is the design brief AMOS implements (originally pasted in chat as a 25-section note on how
to structure a hierarchical Account Management Operating System, rather than one giant "Amazon
automation agent"). Kept here as the reference spec; `HANDOVER.md` tracks build status against it.

## Core principle

Mirror how a real e-commerce agency works:

    Management -> Account Manager -> Department/Domain Specialists -> Task Agents -> Execution -> Verification -> Reporting

Two separate hierarchies:

- **Organisational** — who is responsible for what (`amos/org.py`: Account Director ->
  Department Managers -> Task Agents -> Skills).
- **Execution** — who decides, who analyzes, who executes, who verifies (`amos/engines/`).

## The Account Director

One virtual Account Director per client account (`amos/director.py`). It never edits listings or
campaigns directly; it runs the account through one question loop every cycle: what's happening ->
what's wrong -> why -> what should be done -> who should do it -> was it done -> did it help.

## Departments (organisational hierarchy)

V1 ships three active departments plus compliance/health/pricing/CX as skills feeding into them;
the rest exist in `org.py` as "planned" (agents with no skills yet — see `Agent.implemented`):

1. Account Health   6. Orders & Operations       11. Expansion (later)
2. Catalogue & Content  7. Returns & CX          12. Brand & Creative (later)
3. Advertising      8. Promotions & Growth        13. Finance/Reconciliation (later)
4. Pricing          9. Analytics & BI             14. Competitor Intelligence (later)
5. Inventory        10. Compliance & Marketplace Admin

Each department should *generate issues*, not just reports — e.g. Buy Box dropping 87% -> 21%
should open an investigation routed toward pricing/fulfilment/competitor/stock/listing causes, not
just get logged as a number.

Catalogue changes never happen agent-to-agent directly: audit -> recommendation -> approval ->
execution -> QA. Same discipline for Advertising (data -> analyst -> problem detection -> root
cause -> recommendation -> decision engine -> execution -> verification) and Pricing (price is
derived from cost + fees + shipping + ads + target margin, not just matched to a competitor).

CX connects back to Catalogue: a repeated return reason ("size smaller than expected") should
reach the Catalogue Manager as a size-chart correction task, not stay a CX-only metric.

## Execution hierarchy (`amos/engines/`)

Every task follows the same lifecycle, end to end:

    DETECT -> ANALYZE -> DIAGNOSE -> RECOMMEND -> APPROVE -> EXECUTE -> VERIFY -> MEASURE -> LEARN

- **Exception-driven, not report-driven.** Out of thousands of SKUs, surface only what needs
  attention, bucketed Critical/High/Medium/Monitor — not hundreds of raw recommendations.
- **Agents never call each other directly.** They publish findings/events onto a bus; the
  Task/Decision engine is what connects departments (`Ctx.publish` in `amos/skills/base.py`).
- **Priority = Impact x Urgency x Confidence / Effort**, with a `severity_floor` so e.g.
  suspension risk is always at least P1 regardless of the arithmetic (`engines/priority.py`).
- **Autonomy levels 0–4** gate how much a human must be in the loop, per action type, re-checked
  against hard numeric limits immediately before execution (`engines/policy.py`):
  - L0 automatic (reporting/detection only)
  - L1 agent executes within rules (small, bounded, reversible)
  - L2 agent recommends, human approves
  - L3 agent detects, human decides (no safe default / competing options)
  - L4 human-only (account policy, legal, suspension-risk)
- **Verification** re-checks the underlying issue actually cleared on fresh data before a task is
  allowed to close as fixed (`engines/verification.py`).
- **Learning** measures the relevant metric before/after and records whether the intervention
  actually worked, feeding the weekly report (`engines/learning.py`).

## Skill library (`amos/skills/`)

Agents are bundles of reusable skills rather than bespoke code per department, so adding a new
detector is "write a skill + own it in `org.py`", not "design a new agent". A skill is a pure
`fn(ctx) -> list[Finding]`; it reads data, never calls other agents, and returns findings for the
engines to turn into issues and tasks (`amos/skills/base.py`: `Finding`, `Ctx`, `@skill`).

## Data model

    CLIENT -> ACCOUNT -> MARKETPLACE -> STORE -> PRODUCT/SKU/ASIN

with every account owning tasks, issues, recommendations, actions, reports, campaigns, orders,
inventory, listings and performance history, and every executed action leaving an audit record
(`amos/core.py` schema).

## Build order

V1 (shipped): ingestion, detection, task creation, execution (dry-run/manual), verification —
scoped to Catalogue + Ads + Operations, with Account Health, Pricing, CX and Compliance as skills
feeding the same task engine rather than separate departments yet.

Planned next: V2 richer recommendations, V3 semi-autonomous execution, V4 autonomous execution
within guardrails, V5 cross-client intelligence. Live marketplace connectors (SP-API / Ads API)
replace the current dry-run/manual execution mode without changing anything upstream of
`engines/execution.py`.
